/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { SignatureMenu } from './components/SignatureMenu';
import { SignatureDrink } from './components/SignatureDrink';
import { VideoExperience } from './components/VideoExperience';
import { Gallery } from './components/Gallery';
import { ExperienceCards } from './components/ExperienceCards';
import { ReviewsCarousel } from './components/ReviewsCarousel';
import { Reservation } from './components/Reservation';
import { LocationSection } from './components/LocationSection';
import { InstagramSection } from './components/InstagramSection';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { MenuItem, CartItem } from './types/cafe';

export default function App() {
  const [cartOpen, setCartOpen] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const handleAddToCart = (item: MenuItem, optionDetails?: string) => {
    const existingIndex = cartItems.findIndex(
      (c) => c.item.id === item.id && c.selectedOption === optionDetails
    );

    if (existingIndex > -1) {
      const updated = [...cartItems];
      updated[existingIndex].quantity += 1;
      setCartItems(updated);
    } else {
      const newItem: CartItem = {
        id: `${item.id}-${Date.now()}`,
        item,
        quantity: 1,
        selectedOption: optionDetails
      };
      setCartItems([...cartItems, newItem]);
    }

    // Trigger toast notification
    setToastMessage(`Added "${item.name}" to your order`);
    setTimeout(() => {
      setToastMessage(null);
    }, 2500);
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.id === id) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter((item): item is CartItem => item !== null)
    );
  };

  const handleRemoveItem = (id: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== id));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const handleOpenReservation = () => {
    const elem = document.getElementById('reservation');
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const totalCartCount = cartItems.reduce((acc, curr) => acc + curr.quantity, 0);

  return (
    <div className="min-h-screen bg-[#120E0C] text-[#EADBCC] selection:bg-[#C89B66] selection:text-[#120E0C]">
      {/* Global Navigation */}
      <Navbar
        onOpenReservation={handleOpenReservation}
        onOpenCart={() => setCartOpen(true)}
        cartCount={totalCartCount}
      />

      {/* Main Content Sections */}
      <main>
        {/* 1. Hero Section */}
        <Hero onOpenReservation={handleOpenReservation} />

        {/* 2. About Section */}
        <About onOpenReservation={handleOpenReservation} />

        {/* 3. Signature Menu Section */}
        <SignatureMenu onAddToCart={handleAddToCart} />

        {/* 4. Signature Drink Section */}
        <SignatureDrink onAddToCart={handleAddToCart} />

        {/* 5. Video / Café Experience Section */}
        <VideoExperience />

        {/* 6. Gallery Section */}
        <Gallery />

        {/* 7. Our Experience Feature Cards */}
        <ExperienceCards />

        {/* 8. Customer Reviews Section */}
        <ReviewsCarousel />

        {/* 9. Reservation Section */}
        <Reservation />

        {/* 10. Location / Contact Section */}
        <LocationSection />

        {/* 11. Instagram Social Section */}
        <InstagramSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Slide-out Order Cart Drawer */}
      <CartDrawer
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#1D1512] border border-[#C89B66]/60 text-[#FAF5EF] px-4 py-3 rounded-lg shadow-2xl flex items-center gap-3 text-xs font-medium animate-fadeIn">
          <span className="text-[#C89B66]">✦</span>
          <span>{toastMessage}</span>
          <button
            type="button"
            onClick={() => setCartOpen(true)}
            className="text-[#C89B66] hover:underline uppercase text-[11px] font-bold ml-1 tracking-wider"
          >
            View Order
          </button>
        </div>
      )}
    </div>
  );
}
