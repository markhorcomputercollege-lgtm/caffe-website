import React, { useState } from 'react';
import { ArrowRight, Sparkles, Clock, MapPin } from 'lucide-react';
import aboutImg from '../assets/images/about_cafe_artisan_1790920440454.jpg';
import { StoryModal } from './StoryModal';

interface AboutProps {
  onOpenReservation: () => void;
}

export const About: React.FC<AboutProps> = ({ onOpenReservation }) => {
  const [storyOpen, setStoryOpen] = useState(false);

  return (
    <>
      <section id="about" className="py-24 sm:py-32 bg-[#16110E] relative overflow-hidden">
        {/* Subtle decorative background gradient */}
        <div className="absolute top-1/2 left-0 w-96 h-96 bg-[#C89B66]/5 rounded-full blur-3xl pointer-events-none -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-80 h-80 bg-[#C89B66]/5 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
            {/* Left Column: Large realistic café image */}
            <div className="lg:col-span-6 relative">
              <div className="relative z-10 rounded-2xl overflow-hidden border border-[#3A2B23] shadow-2xl group">
                <img
                  src={aboutImg}
                  alt="Aura Café master barista pouring silky latte art"
                  className="w-full h-[450px] sm:h-[540px] object-cover object-center transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#16110E] via-transparent to-transparent opacity-60" />
                
                {/* Floating badge inside image corner */}
                <div className="absolute bottom-6 left-6 right-6 p-4 rounded-xl bg-[#1A1411]/90 backdrop-blur-md border border-[#3E2E25] shadow-xl flex items-center justify-between">
                  <div>
                    <p className="text-[11px] uppercase tracking-wider text-[#C89B66] font-semibold">Specialty Roast</p>
                    <p className="text-sm font-medium text-[#FAF5EF]">Ethiopian Yirgacheffe G1</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[11px] uppercase tracking-wider text-[#9E8B7E]">Tasting Notes</p>
                    <p className="text-xs text-[#E5C396]">Bergamot · Jasmine · Peach</p>
                  </div>
                </div>
              </div>

              {/* Decorative accent frame underneath */}
              <div className="absolute -top-4 -left-4 w-full h-full border border-[#C89B66]/20 rounded-2xl pointer-events-none hidden sm:block -z-0" />
            </div>

            {/* Right Column: Story Copy */}
            <div className="lg:col-span-6 flex flex-col justify-center">
              {/* Unboxed natural kicker */}
              <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-[#C89B66] font-medium mb-3">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Our Philosophy</span>
              </div>

              {/* Main Heading */}
              <h2 className="text-4xl sm:text-5xl font-serif text-[#FAF5EF] tracking-tight leading-tight mb-6 text-balance">
                More Than Just Coffee
              </h2>

              {/* Prose narrative */}
              <div className="space-y-4 text-base sm:text-lg text-[#C8B8A9] font-light leading-relaxed mb-8">
                <p>
                  At <strong className="text-[#FAF5EF] font-medium">AURA CAFÉ</strong>, we believe every cup should be an invitation to slow down and savor life’s finest textures. Our space was born from a simple desire: to blend artisan micro-roasting with hearth-baked warmth and heartfelt hospitality.
                </p>
                <p>
                  From hand-selected single-origin beans roasted to perfection, to golden croissants rolled fresh every morning, each detail is a labor of dedication. We are a sanctuary for quiet conversations, creative breakthroughs, and memories forged over steaming cups.
                </p>
              </div>

              {/* Editorial Highlights */}
              <div className="grid grid-cols-2 gap-6 pt-2 pb-8 border-y border-[#2C1F19] mb-8">
                <div className="flex items-start gap-3">
                  <Clock className="w-5 h-5 text-[#C89B66] shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-semibold text-[#FAF5EF]">Unhurried Rituals</h4>
                    <p className="text-xs text-[#9E8B7E] mt-0.5">Crafted at your pace, designed for mindful moments.</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-[#C89B66] shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-semibold text-[#FAF5EF]">Urban Sanctuary</h4>
                    <p className="text-xs text-[#9E8B7E] mt-0.5">Warm walnut, soft acoustics, and tranquil light.</p>
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div id="story">
                <button
                  type="button"
                  onClick={() => setStoryOpen(true)}
                  className="inline-flex items-center gap-3 px-6 py-3.5 text-xs sm:text-sm font-semibold uppercase tracking-wider text-[#FAF5EF] bg-[#2A1E19] hover:bg-[#382821] border border-[#48342B] hover:border-[#C89B66] rounded-md transition-all shadow-md group"
                >
                  <span>Discover Our Story</span>
                  <ArrowRight className="w-4 h-4 text-[#C89B66] transition-transform group-hover:translate-x-1" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Story Heritage Modal */}
      <StoryModal
        isOpen={storyOpen}
        onClose={() => setStoryOpen(false)}
        onOpenReservation={onOpenReservation}
      />
    </>
  );
};
