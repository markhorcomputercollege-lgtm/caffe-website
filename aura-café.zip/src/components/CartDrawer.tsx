import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, CheckCircle, ArrowRight } from 'lucide-react';
import { CartItem } from '../types/cafe';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart
}) => {
  const [orderType, setOrderType] = useState<'Dine-in' | 'Takeaway'>('Dine-in');
  const [tableNumber, setTableNumber] = useState('12');
  const [isOrdering, setIsOrdering] = useState(false);
  const [confirmedOrder, setConfirmedOrder] = useState<{
    orderNumber: string;
    total: number;
    type: string;
    itemCount: number;
  } | null>(null);

  if (!isOpen) return null;

  const subtotal = items.reduce((acc, curr) => acc + curr.item.price * curr.quantity, 0);
  const tax = subtotal * 0.08;
  const total = subtotal + tax;

  const handlePlaceOrder = () => {
    setIsOrdering(true);
    setTimeout(() => {
      const orderNum = `AUR-${Math.floor(100 + Math.random() * 900)}`;
      setConfirmedOrder({
        orderNumber: orderNum,
        total,
        type: orderType,
        itemCount: items.reduce((sum, i) => sum + i.quantity, 0)
      });
      setIsOrdering(false);
      onClearCart();
    }, 800);
  };

  const handleDone = () => {
    setConfirmedOrder(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end animate-fadeIn">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/75 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Drawer */}
      <div className="relative z-10 w-full max-w-md bg-[#18120F] border-l border-[#35251D] shadow-2xl h-full flex flex-col justify-between overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-[#2C1E18] bg-[#140E0C] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-[#C89B66]" />
            <h3 className="text-lg font-serif text-[#FAF5EF]">Your Café Order</h3>
            {items.length > 0 && (
              <span className="text-xs text-[#A89688]">({items.reduce((sum, i) => sum + i.quantity, 0)} items)</span>
            )}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-[#9E8B7E] hover:text-white rounded-md transition-colors"
            aria-label="Close cart"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {confirmedOrder ? (
            <div className="py-12 text-center space-y-5">
              <div className="w-16 h-16 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto shadow-xl">
                <CheckCircle className="w-8 h-8" />
              </div>
              <div>
                <span className="text-xs uppercase tracking-widest text-[#C89B66] font-semibold">
                  Order Received
                </span>
                <h4 className="text-2xl font-serif text-[#FAF5EF] mt-1 mb-2">
                  Order #{confirmedOrder.orderNumber}
                </h4>
                <p className="text-xs text-[#A89688] max-w-xs mx-auto">
                  Our baristas and bakery team have received your order. Est. preparation time: 10–12 minutes.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#201713] border border-[#34241C] text-xs text-left max-w-xs mx-auto space-y-2">
                <div className="flex justify-between">
                  <span className="text-[#9E8B7E]">Order Type</span>
                  <span className="text-[#FAF5EF] font-medium">{confirmedOrder.type}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#9E8B7E]">Total Paid</span>
                  <span className="text-[#E5C396] font-bold tabular-nums">${confirmedOrder.total.toFixed(2)}</span>
                </div>
              </div>

              <button
                type="button"
                onClick={handleDone}
                className="w-full max-w-xs py-3 text-xs font-semibold uppercase tracking-wider text-[#120E0C] bg-[#C89B66] hover:bg-[#D7A873] rounded-md transition-colors"
              >
                Close & Return to Menu
              </button>
            </div>
          ) : items.length === 0 ? (
            <div className="py-20 text-center space-y-4">
              <div className="w-14 h-14 rounded-full bg-[#241A15] text-[#8A7569] flex items-center justify-center mx-auto">
                <ShoppingBag className="w-6 h-6" />
              </div>
              <h4 className="text-xl font-serif text-[#FAF5EF]">Your Order is Empty</h4>
              <p className="text-xs text-[#A89688] max-w-xs mx-auto">
                Explore our signature coffees, flaky morning pastries, and artisanal desserts to begin your order.
              </p>
              <button
                type="button"
                onClick={onClose}
                className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-[#120E0C] bg-[#C89B66] rounded-md hover:bg-[#D7A873] transition-colors"
              >
                Browse Menu
              </button>
            </div>
          ) : (
            <>
              {/* Order Type Toggle */}
              <div className="p-3 bg-[#1F1713] rounded-xl border border-[#34241C] flex items-center justify-between">
                <span className="text-xs text-[#9E8B7E] font-medium">Service Style:</span>
                <div className="flex items-center gap-1">
                  {(['Dine-in', 'Takeaway'] as const).map((type) => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => setOrderType(type)}
                      className={`px-3 py-1 rounded text-xs transition-colors ${
                        orderType === type
                          ? 'bg-[#C89B66] text-[#120E0C] font-semibold'
                          : 'text-[#C5B5A6] hover:text-white'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              {orderType === 'Dine-in' && (
                <div className="flex items-center justify-between text-xs px-2 text-[#9E8B7E]">
                  <span>Table / Seating #:</span>
                  <input
                    type="text"
                    value={tableNumber}
                    onChange={(e) => setTableNumber(e.target.value)}
                    className="w-16 px-2 py-1 rounded bg-[#241A16] border border-[#38271F] text-center text-[#FAF5EF] text-xs"
                  />
                </div>
              )}

              {/* Items List */}
              <div className="space-y-3 pt-2">
                {items.map((cartItem) => (
                  <div
                    key={cartItem.id}
                    className="p-3 bg-[#201814] rounded-xl border border-[#34241C] flex items-center gap-3"
                  >
                    <img
                      src={cartItem.item.image}
                      alt={cartItem.item.name}
                      className="w-14 h-14 rounded-lg object-cover"
                      referrerPolicy="no-referrer"
                    />

                    <div className="flex-1 min-w-0">
                      <h5 className="text-sm font-serif font-medium text-[#FAF5EF] truncate">
                        {cartItem.item.name}
                      </h5>
                      {cartItem.selectedOption && (
                        <p className="text-[11px] text-[#C89B66] truncate">
                          {cartItem.selectedOption}
                        </p>
                      )}
                      <span className="text-xs font-semibold text-[#E5C396] tabular-nums">
                        ${(cartItem.item.price * cartItem.quantity).toFixed(2)}
                      </span>
                    </div>

                    {/* Quantity Controls */}
                    <div className="flex items-center gap-2">
                      <div className="flex items-center border border-[#3E2D23] rounded-lg bg-[#18120F]">
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(cartItem.id, -1)}
                          className="p-1 text-[#A89688] hover:text-white"
                          aria-label="Decrease quantity"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="px-2 text-xs font-bold text-[#FAF5EF] tabular-nums">
                          {cartItem.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(cartItem.id, 1)}
                          className="p-1 text-[#A89688] hover:text-white"
                          aria-label="Increase quantity"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <button
                        type="button"
                        onClick={() => onRemoveItem(cartItem.id)}
                        className="p-1.5 text-[#8A7569] hover:text-red-400 transition-colors"
                        aria-label="Remove item"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Footer with Subtotal & Checkout */}
        {items.length > 0 && !confirmedOrder && (
          <div className="p-5 border-t border-[#2C1E18] bg-[#140E0C] space-y-3">
            <div className="space-y-1.5 text-xs text-[#A89688]">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="text-[#FAF5EF] tabular-nums">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Estimated Tax (8%)</span>
                <span className="text-[#FAF5EF] tabular-nums">${tax.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-base font-serif font-semibold text-[#FAF5EF] pt-2 border-t border-[#241A15]">
                <span>Total</span>
                <span className="text-[#E5C396] tabular-nums">${total.toFixed(2)}</span>
              </div>
            </div>

            <button
              type="button"
              onClick={handlePlaceOrder}
              disabled={isOrdering}
              className="w-full py-3.5 text-xs font-semibold uppercase tracking-wider text-[#120E0C] bg-gradient-to-r from-[#D7A873] via-[#C89B66] to-[#B38753] hover:from-[#E4BA87] hover:to-[#C89B66] rounded-md transition-all shadow-xl active:scale-[0.98] flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <span>{isOrdering ? 'Processing Order...' : 'Confirm Order'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
