import React from 'react';
import { Sparkles } from 'lucide-react';
import { EXPERIENCE_FEATURES } from '../data/cafeData';

export const ExperienceCards: React.FC = () => {
  return (
    <section className="py-24 sm:py-28 bg-[#120E0C] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-[#C89B66] font-medium mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>The Aura Difference</span>
          </div>
          <h2 className="text-4xl sm:text-5xl font-serif text-[#FAF5EF] tracking-tight leading-tight mb-4">
            Our Experience
          </h2>
          <p className="text-base text-[#B5A496] font-light">
            Every moment in our café is choreographed with subtle elegance, sensory richness, and heartfelt dedication.
          </p>
        </div>

        {/* 4 Feature Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {EXPERIENCE_FEATURES.map((feature, idx) => (
            <div
              key={idx}
              className="group p-8 rounded-2xl bg-[#18120F] border border-[#2F2119] hover:border-[#C89B66]/70 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-1.5 flex flex-col justify-between relative overflow-hidden"
            >
              {/* Subtle gold glow accent in corner on hover */}
              <div className="absolute top-0 right-0 w-24 h-24 bg-[#C89B66]/0 group-hover:bg-[#C89B66]/10 rounded-bl-full transition-all duration-500 pointer-events-none" />

              <div>
                {/* Large Distinctive Icon */}
                <div className="w-14 h-14 rounded-xl bg-[#231A15] border border-[#3A2920] group-hover:border-[#C89B66]/50 flex items-center justify-center text-2xl mb-6 transition-transform duration-300 group-hover:scale-110 shadow-inner">
                  <span>{feature.icon}</span>
                </div>

                <div className="mb-2">
                  <span className="text-[11px] uppercase tracking-wider text-[#C89B66] font-semibold block">
                    {feature.subtitle}
                  </span>
                  <h3 className="text-2xl font-serif font-medium text-[#FAF5EF] mt-1 group-hover:text-[#E5C396] transition-colors">
                    {feature.title}
                  </h3>
                </div>

                <p className="text-xs sm:text-sm text-[#A89688] font-light leading-relaxed mt-3">
                  {feature.description}
                </p>
              </div>

              {/* Number watermark/indicator */}
              <div className="mt-8 pt-4 border-t border-[#291D16] flex items-center justify-between text-[11px] text-[#786457]">
                <span>Pillar 0{idx + 1}</span>
                <span className="text-[#C89B66] font-serif">✦</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
