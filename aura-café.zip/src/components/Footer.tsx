import React, { useState } from 'react';
import { Sparkles, Instagram, Facebook, ArrowUp, Send, Check } from 'lucide-react';

export const Footer: React.FC = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) return;
    setSubscribed(true);
    setTimeout(() => {
      setEmail('');
      setSubscribed(false);
    }, 3000);
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#0D0A08] border-t border-[#2A1D17] text-[#C5B5A6] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-12">
          {/* Brand Column */}
          <div className="lg:col-span-4 space-y-4">
            <a href="#home" className="text-2xl sm:text-3xl font-serif tracking-widest text-[#FAF5EF] flex items-center gap-2">
              <span className="text-[#C89B66]">✦</span>
              <span>AURA CAFÉ</span>
            </a>
            <p className="text-sm font-serif italic text-[#D8B998] font-light">
              “Where Every Sip Tells a Story.”
            </p>
            <p className="text-xs text-[#9E8B7E] font-light leading-relaxed max-w-sm">
              Artisanal single-origin coffee roasting, hearthside baking, and mindful hospitality nestled in the historic quarter.
            </p>

            {/* Social Icons */}
            <div className="flex items-center gap-3 pt-2">
              {/* Instagram */}
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-[#1A1411] border border-[#33251E] hover:border-[#C89B66] text-[#C5B5A6] hover:text-[#C89B66] flex items-center justify-center transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>

              {/* Facebook */}
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-[#1A1411] border border-[#33251E] hover:border-[#C89B66] text-[#C5B5A6] hover:text-[#C89B66] flex items-center justify-center transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>

              {/* TikTok (custom clean SVG) */}
              <a
                href="https://tiktok.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-[#1A1411] border border-[#33251E] hover:border-[#C89B66] text-[#C5B5A6] hover:text-[#C89B66] flex items-center justify-center transition-colors"
                aria-label="TikTok"
              >
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64c.29 0 .58.04.86.12V9.42a6.37 6.37 0 0 0-6.62 6.36 6.34 6.34 0 0 0 10.82 4.48c1.68-1.7 2.1-4.04 2.1-6.19v-4.83c1.23.88 2.7 1.41 4.29 1.45V6.69h-.34z" />
                </svg>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs uppercase tracking-widest text-[#FAF5EF] font-semibold">
              Quick Links
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#home" className="hover:text-[#C89B66] transition-colors">Home</a>
              </li>
              <li>
                <a href="#about" className="hover:text-[#C89B66] transition-colors">About</a>
              </li>
              <li>
                <a href="#menu" className="hover:text-[#C89B66] transition-colors">Menu</a>
              </li>
              <li>
                <a href="#gallery" className="hover:text-[#C89B66] transition-colors">Gallery</a>
              </li>
              <li>
                <a href="#contact" className="hover:text-[#C89B66] transition-colors">Contact</a>
              </li>
              <li>
                <a href="#reservation" className="text-[#C89B66] hover:underline transition-colors font-medium">Reservations</a>
              </li>
            </ul>
          </div>

          {/* Opening Hours Column */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs uppercase tracking-widest text-[#FAF5EF] font-semibold">
              Opening Hours
            </h4>
            <div className="space-y-2 text-xs text-[#A89688]">
              <p>
                <strong className="text-[#FAF5EF] block font-medium">Monday – Friday</strong>
                8:00 AM – 10:00 PM
              </p>
              <p>
                <strong className="text-[#FAF5EF] block font-medium">Saturday – Sunday</strong>
                9:00 AM – 11:00 PM
              </p>
              <p className="pt-2 text-[11px] text-[#7A675A]">
                Hearth bakes hot and fresh out of the ovens by 8:30 AM daily.
              </p>
            </div>
          </div>

          {/* Newsletter Column */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs uppercase tracking-widest text-[#FAF5EF] font-semibold">
              Coffee Notes Newsletter
            </h4>
            <p className="text-xs text-[#9E8B7E] font-light leading-relaxed">
              Receive seasonal harvest announcements, secret dessert tasting invites, and barista brew guides.
            </p>

            <form onSubmit={handleSubscribe} className="space-y-2">
              <div className="relative">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your.email@domain.com"
                  className="w-full px-3.5 py-2.5 rounded-lg bg-[#18120F] border border-[#33251E] text-xs text-[#FAF5EF] placeholder-[#735F52] focus:outline-none focus:border-[#C89B66]"
                />
                <button
                  type="submit"
                  aria-label="Subscribe"
                  className="absolute right-1 top-1 bottom-1 px-3 bg-[#C89B66] hover:bg-[#D7A873] text-[#120E0C] rounded-md flex items-center justify-center transition-colors"
                >
                  {subscribed ? <Check className="w-3.5 h-3.5" /> : <Send className="w-3.5 h-3.5" />}
                </button>
              </div>
              {subscribed && (
                <p className="text-[11px] text-emerald-400">
                  Welcome to the Aura Coffee Club!
                </p>
              )}
            </form>
          </div>
        </div>

        {/* Bottom Bar: Copyright & Back to Top */}
        <div className="mt-14 pt-8 border-t border-[#201612] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#786457]">
          <p>© 2026 AURA CAFÉ. All rights reserved. Where Every Sip Tells a Story.</p>

          <button
            type="button"
            onClick={scrollToTop}
            className="flex items-center gap-1.5 text-[#9E8B7E] hover:text-[#C89B66] transition-colors cursor-pointer"
          >
            <span>Back to top</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </footer>
  );
};
