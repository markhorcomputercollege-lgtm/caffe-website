import React, { useState, useEffect } from 'react';
import { Eye, X, ChevronLeft, ChevronRight, Sparkles } from 'lucide-react';
import { GalleryCategory, GalleryItem } from '../types/cafe';
import { GALLERY_ITEMS } from '../data/cafeData';

export const Gallery: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<GalleryCategory>('All');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const categories: GalleryCategory[] = ['All', 'Coffee', 'Interior', 'Desserts', 'People', 'Atmosphere'];

  const filteredItems = activeCategory === 'All'
    ? GALLERY_ITEMS
    : GALLERY_ITEMS.filter((item) => item.category === activeCategory);

  // Keyboard navigation for lightbox
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (lightboxIndex === null) return;
      if (e.key === 'Escape') {
        setLightboxIndex(null);
      } else if (e.key === 'ArrowRight') {
        setLightboxIndex((prev) => (prev !== null ? (prev + 1) % filteredItems.length : null));
      } else if (e.key === 'ArrowLeft') {
        setLightboxIndex((prev) => (prev !== null ? (prev - 1 + filteredItems.length) % filteredItems.length : null));
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [lightboxIndex, filteredItems.length]);

  const openLightbox = (item: GalleryItem) => {
    const index = filteredItems.findIndex((it) => it.id === item.id);
    if (index !== -1) {
      setLightboxIndex(index);
    }
  };

  const currentLightboxItem = lightboxIndex !== null ? filteredItems[lightboxIndex] : null;

  return (
    <section id="gallery" className="py-24 sm:py-32 bg-[#16110E] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-[#C89B66] font-medium mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Visual Chronicles</span>
          </div>
          <h2 className="text-4xl sm:text-5xl font-serif text-[#FAF5EF] tracking-tight leading-tight mb-4">
            Café Gallery
          </h2>
          <p className="text-base text-[#B5A496] font-light">
            Glimpses into our daily coffee craft, hearthside morning bakes, and the quiet beauty of our space.
          </p>

          {/* Category Tabs */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-2 p-1.5 bg-[#1F1713] border border-[#362720] rounded-xl max-w-fit mx-auto">
            {categories.map((cat) => {
              const isActive = activeCategory === cat;
              return (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setActiveCategory(cat)}
                  className={`px-4 py-2 text-xs sm:text-sm font-medium rounded-lg transition-all cursor-pointer ${
                    isActive
                      ? 'bg-[#C89B66] text-[#120E0C] font-semibold shadow'
                      : 'text-[#C5B5A6] hover:text-[#FAF5EF] hover:bg-[#2A1E18]'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>
        </div>

        {/* Masonry / Responsive Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              onClick={() => openLightbox(item)}
              className="group relative rounded-xl overflow-hidden bg-[#201814] border border-[#34241C] shadow-lg cursor-pointer aspect-4/3 sm:aspect-auto sm:h-80"
            >
              {/* Image with zoom on hover */}
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-110"
                referrerPolicy="no-referrer"
              />

              {/* Dark Overlay with subtle gold tint */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent opacity-60 group-hover:opacity-90 transition-opacity duration-300" />

              {/* View Icon and Text overlay */}
              <div className="absolute inset-0 p-6 flex flex-col justify-between z-10">
                <div className="flex justify-between items-start">
                  <span className="text-[11px] uppercase tracking-wider text-[#FAF5EF] font-medium bg-[#120E0C]/80 px-2.5 py-1 rounded backdrop-blur-sm">
                    {item.category}
                  </span>
                  <div className="w-9 h-9 rounded-full bg-[#C89B66] text-[#120E0C] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 transform scale-75 group-hover:scale-100 shadow-lg">
                    <Eye className="w-4 h-4" />
                  </div>
                </div>

                <div className="transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                  <h3 className="text-lg font-serif font-medium text-[#FAF5EF] mb-1">
                    {item.title}
                  </h3>
                  <p className="text-xs text-[#C5B5A6] font-light line-clamp-2">
                    {item.caption}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Fullscreen Lightbox Modal */}
      {currentLightboxItem && lightboxIndex !== null && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md p-4 sm:p-8 animate-fadeIn">
          {/* Close Button */}
          <button
            type="button"
            onClick={() => setLightboxIndex(null)}
            className="absolute top-6 right-6 p-2 text-[#C5B5A6] hover:text-white rounded-full bg-white/10 hover:bg-white/20 transition-all z-50 cursor-pointer"
            aria-label="Close lightbox"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Prev Button */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setLightboxIndex((lightboxIndex - 1 + filteredItems.length) % filteredItems.length);
            }}
            className="absolute left-4 sm:left-8 top-1/2 -translate-y-1/2 p-3 text-white/80 hover:text-white rounded-full bg-white/10 hover:bg-[#C89B66] transition-all z-50 cursor-pointer"
            aria-label="Previous image"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          {/* Next Button */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setLightboxIndex((lightboxIndex + 1) % filteredItems.length);
            }}
            className="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 p-3 text-white/80 hover:text-white rounded-full bg-white/10 hover:bg-[#C89B66] transition-all z-50 cursor-pointer"
            aria-label="Next image"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Lightbox Content Container */}
          <div className="max-w-4xl max-h-[85vh] flex flex-col items-center justify-center">
            <img
              src={currentLightboxItem.image}
              alt={currentLightboxItem.title}
              className="max-h-[70vh] w-auto max-w-full object-contain rounded-lg border border-[#3C2E25] shadow-2xl"
              referrerPolicy="no-referrer"
            />
            <div className="mt-4 text-center max-w-xl">
              <span className="text-xs uppercase tracking-widest text-[#C89B66] font-semibold">
                {currentLightboxItem.category} · {lightboxIndex + 1} of {filteredItems.length}
              </span>
              <h3 className="text-2xl font-serif text-[#FAF5EF] mt-1 mb-1">
                {currentLightboxItem.title}
              </h3>
              <p className="text-xs sm:text-sm text-[#A89688] font-light">
                {currentLightboxItem.caption}
              </p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
