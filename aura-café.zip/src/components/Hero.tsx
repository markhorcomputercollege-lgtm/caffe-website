import React from 'react';
import { ChevronDown, Coffee, Sparkles } from 'lucide-react';
import heroBg from '../assets/images/hero_cafe_interior_1790920421286.jpg';

interface HeroProps {
  onOpenReservation: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenReservation }) => {
  return (
    <section
      id="home"
      className="relative min-h-screen w-full flex items-center justify-center overflow-hidden bg-[#120E0C]"
    >
      {/* Background Image with Cinematic Grading & Depth Scrim */}
      <div className="absolute inset-0 z-0">
        <img
          src={heroBg}
          alt="Aura Café luxury ambient interior with warm glowing lights and artisan espresso bar"
          className="w-full h-full object-cover object-center scale-105 animate-[pulse_10s_ease-in-out_infinite_alternate]"
          referrerPolicy="no-referrer"
        />
        {/* Multi-layered cinematic scrim for text contrast & warm vignette */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#120E0C] via-[#120E0C]/60 to-[#120E0C]/40" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_30%,#120E0C_100%)] opacity-80" />
      </div>

      {/* Floating Ambient Warm Gold Dust Particles */}
      <div className="absolute inset-0 pointer-events-none z-10 overflow-hidden">
        <div className="absolute top-1/4 left-1/6 w-2 h-2 rounded-full bg-[#E5C396]/40 blur-[1px] animate-float" />
        <div className="absolute top-1/3 right-1/5 w-1.5 h-1.5 rounded-full bg-[#C89B66]/50 blur-[1px] animate-[floatGentle_7s_ease-in-out_infinite_1.5s]" />
        <div className="absolute bottom-1/3 left-1/4 w-2.5 h-2.5 rounded-full bg-[#E5C396]/30 blur-[2px] animate-[floatGentle_8s_ease-in-out_infinite_3s]" />
        <div className="absolute top-1/2 right-1/3 w-1.5 h-1.5 rounded-full bg-[#C89B66]/40 blur-[1px] animate-[floatGentle_5.5s_ease-in-out_infinite_2s]" />
        <div className="absolute bottom-1/4 right-1/6 w-2 h-2 rounded-full bg-[#E5C396]/40 blur-[1.5px] animate-float" />
      </div>

      {/* Hero Content */}
      <div className="relative z-20 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-24 pb-16 flex flex-col items-center">
        {/* Subtle Brand Kicker */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#201712]/80 border border-[#433127]/60 backdrop-blur-sm text-xs font-medium text-[#D8B998] tracking-widest uppercase mb-6 shadow-sm">
          <Sparkles className="w-3.5 h-3.5 text-[#C89B66]" />
          <span>Artisanal Coffee & Hearth Bakery</span>
        </div>

        {/* Brand Name */}
        <h1 className="text-5xl sm:text-7xl lg:text-8xl font-serif font-light tracking-[0.18em] text-[#FAF5EF] uppercase mb-4 drop-shadow-lg text-balance">
          AURA CAFÉ
        </h1>

        {/* Tagline */}
        <p className="text-2xl sm:text-3xl lg:text-4xl font-serif italic text-[#E5C396] font-normal mb-5 tracking-wide max-w-3xl drop-shadow">
          “Where Every Sip Tells a Story.”
        </p>

        {/* Subtitle */}
        <p className="text-base sm:text-lg text-[#C8B8A9] max-w-xl mb-10 leading-relaxed font-light">
          Crafted coffee, fresh flavors, and beautiful moments. Step into our sanctuary of warmth and slow luxury.
        </p>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center gap-4 sm:gap-5 w-full sm:w-auto">
          <a
            href="#menu"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3.5 text-xs sm:text-sm font-semibold uppercase tracking-widest text-[#120E0C] bg-[#C89B66] hover:bg-[#D7A873] rounded-md transition-all shadow-lg hover:shadow-[#C89B66]/25 active:scale-[0.98]"
          >
            <Coffee className="w-4 h-4" />
            <span>EXPLORE MENU</span>
          </a>

          <button
            type="button"
            onClick={onOpenReservation}
            className="w-full sm:w-auto inline-flex items-center justify-center px-8 py-3.5 text-xs sm:text-sm font-semibold uppercase tracking-widest text-[#FAF5EF] border border-[#C89B66]/60 hover:bg-[#C89B66]/15 hover:border-[#C89B66] rounded-md backdrop-blur-sm transition-all shadow-md active:scale-[0.98]"
          >
            BOOK A TABLE
          </button>
        </div>

        {/* Quick Highlights / Trust Bar */}
        <div className="mt-16 pt-8 border-t border-[#3B2B23]/50 grid grid-cols-2 md:grid-cols-4 gap-6 sm:gap-10 text-center w-full max-w-3xl">
          <div>
            <p className="text-xs uppercase tracking-wider text-[#9E8B7E]">Single Origin</p>
            <p className="text-sm font-medium text-[#FAF5EF] mt-0.5">Ethiopia & Colombia</p>
          </div>
          <div>
            <p className="text-xs uppercase tracking-wider text-[#9E8B7E]">Daily Bake</p>
            <p className="text-sm font-medium text-[#FAF5EF] mt-0.5">Fresh at 6:30 AM</p>
          </div>
          <div>
            <p className="text-xs uppercase tracking-wider text-[#9E8B7E]">Atmosphere</p>
            <p className="text-sm font-medium text-[#FAF5EF] mt-0.5">Acoustic & Cozy</p>
          </div>
          <div>
            <p className="text-xs uppercase tracking-wider text-[#9E8B7E]">Rating</p>
            <p className="text-sm font-medium text-[#C89B66] mt-0.5">★ 4.9 · 1,200+ Reviews</p>
          </div>
        </div>
      </div>

      {/* Subtle Animated Scroll Down Indicator */}
      <a
        href="#about"
        className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-1 text-[#A89485] hover:text-[#C89B66] transition-colors group cursor-pointer"
        aria-label="Scroll to About section"
      >
        <span className="text-[10px] uppercase tracking-widest font-medium opacity-80 group-hover:opacity-100">
          Scroll Down
        </span>
        <ChevronDown className="w-4 h-4 animate-bounce text-[#C89B66]" />
      </a>
    </section>
  );
};
