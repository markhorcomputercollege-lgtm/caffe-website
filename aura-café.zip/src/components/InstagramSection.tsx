import React, { useState } from 'react';
import { Heart, MessageCircle, Instagram, Sparkles, ExternalLink, X } from 'lucide-react';
import { INSTAGRAM_POSTS } from '../data/cafeData';

export const InstagramSection: React.FC = () => {
  const [selectedPost, setSelectedPost] = useState<typeof INSTAGRAM_POSTS[0] | null>(null);
  const [likedPosts, setLikedPosts] = useState<{ [id: string]: boolean }>({});

  const toggleLike = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setLikedPosts((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <section className="py-24 sm:py-32 bg-[#120E0C] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-[#C89B66] font-medium mb-3">
            <Instagram className="w-3.5 h-3.5" />
            <span>Social Journal</span>
          </div>
          <h2 className="text-4xl sm:text-5xl font-serif text-[#FAF5EF] tracking-tight leading-tight mb-4">
            Follow Our Coffee Moments
          </h2>
          <p className="text-base text-[#B5A496] font-light mb-6">
            Tag <strong className="text-[#E5C396] font-medium">#AuraMoments</strong> on Instagram to be featured in our weekly guest stories.
          </p>

          {/* Social Handle Action Button */}
          <a
            href="https://instagram.com"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#201713] hover:bg-[#2C1F1A] border border-[#3E2D23] hover:border-[#C89B66] text-xs font-semibold tracking-wider text-[#FAF5EF] transition-all shadow-md group"
          >
            <Instagram className="w-4 h-4 text-[#C89B66] group-hover:scale-110 transition-transform" />
            <span>@auracafe</span>
            <ExternalLink className="w-3 h-3 text-[#8A7569]" />
          </a>
        </div>

        {/* 6 Square Images Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
          {INSTAGRAM_POSTS.map((post) => {
            const isLiked = !!likedPosts[post.id];
            const currentLikes = post.likes + (isLiked ? 1 : 0);

            return (
              <div
                key={post.id}
                onClick={() => setSelectedPost(post)}
                className="group relative aspect-square rounded-xl overflow-hidden bg-[#201814] border border-[#30221A] cursor-pointer shadow-md"
              >
                <img
                  src={post.image}
                  alt={post.caption}
                  className="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />

                {/* Dark Hover Overlay with Likes & Comments */}
                <div className="absolute inset-0 bg-black/75 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-center gap-3 p-3 text-center">
                  <div className="flex items-center gap-4 text-xs font-semibold text-white">
                    <span className="flex items-center gap-1">
                      <Heart
                        onClick={(e) => toggleLike(post.id, e)}
                        className={`w-4 h-4 transition-colors ${
                          isLiked ? 'text-red-500 fill-red-500' : 'text-white'
                        }`}
                      />
                      <span className="tabular-nums">{currentLikes}</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageCircle className="w-4 h-4 text-white" />
                      <span className="tabular-nums">{post.comments}</span>
                    </span>
                  </div>
                  <span className="text-[10px] text-[#D8B998] font-medium tracking-wide">
                    Click to view
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Instagram Post Detail Modal */}
      {selectedPost && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-lg bg-[#1B1411] border border-[#3E2D22] rounded-xl overflow-hidden shadow-2xl text-[#EADBCC]">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-[#2C1F19] bg-[#140F0D]">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-full bg-[#C89B66] text-[#120E0C] text-xs font-bold flex items-center justify-center">
                  A
                </div>
                <div>
                  <p className="text-xs font-semibold text-[#FAF5EF]">auracafe</p>
                  <p className="text-[10px] text-[#8A7569]">AURA CAFÉ · 123 Coffee Street</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedPost(null)}
                className="text-[#9E8B7E] hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="relative aspect-square w-full bg-black">
              <img
                src={selectedPost.image}
                alt={selectedPost.caption}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="p-5 space-y-3">
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-4">
                  <button
                    type="button"
                    onClick={(e) => toggleLike(selectedPost.id, e)}
                    className="flex items-center gap-1.5 cursor-pointer"
                  >
                    <Heart
                      className={`w-5 h-5 ${
                        likedPosts[selectedPost.id] ? 'text-red-500 fill-red-500' : 'text-white'
                      }`}
                    />
                    <span className="text-xs font-semibold tabular-nums">
                      {selectedPost.likes + (likedPosts[selectedPost.id] ? 1 : 0)} likes
                    </span>
                  </button>
                  <span className="flex items-center gap-1.5 text-xs text-[#A89688]">
                    <MessageCircle className="w-5 h-5" />
                    <span>{selectedPost.comments} comments</span>
                  </span>
                </div>
              </div>

              <p className="text-xs text-[#C5B5A6] leading-relaxed">
                <strong className="text-[#FAF5EF] mr-1.5">auracafe</strong>
                {selectedPost.caption}
              </p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
