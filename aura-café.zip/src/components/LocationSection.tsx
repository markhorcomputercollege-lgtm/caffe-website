import React, { useState } from 'react';
import { MapPin, Clock, Phone, Mail, Navigation, ExternalLink, Sparkles, Compass } from 'lucide-react';

export const LocationSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'map' | 'transit'>('map');
  const [copiedContact, setCopiedContact] = useState<string | null>(null);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedContact(label);
    setTimeout(() => setCopiedContact(null), 2000);
  };

  return (
    <section id="contact" className="py-24 sm:py-32 bg-[#16110E] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-[#C89B66] font-medium mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Visit Us</span>
          </div>
          <h2 className="text-4xl sm:text-5xl font-serif text-[#FAF5EF] tracking-tight leading-tight mb-4">
            Location & Hours
          </h2>
          <p className="text-base text-[#B5A496] font-light">
            Conveniently situated in the historic city quarter, framed by cobblestone walkways and natural greenery.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 sm:gap-12 items-stretch">
          {/* Left Column: Contact & Hours Details */}
          <div className="lg:col-span-5 bg-[#1B1411] border border-[#34241C] rounded-2xl p-8 sm:p-10 shadow-2xl flex flex-col justify-between">
            <div className="space-y-8">
              {/* Brand & Address */}
              <div>
                <span className="text-2xl font-serif text-[#FAF5EF] block mb-2 tracking-wide">
                  AURA CAFÉ
                </span>
                <div className="flex items-start gap-3 text-sm text-[#C5B5A6]">
                  <MapPin className="w-5 h-5 text-[#C89B66] shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-[#FAF5EF]">123 Coffee Street</p>
                    <p className="text-xs text-[#9E8B7E]">Metropolis District, Your City 10001</p>
                  </div>
                </div>
              </div>

              {/* Opening Hours */}
              <div className="pt-6 border-t border-[#2C1F19]">
                <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-[#C89B66] font-semibold mb-3">
                  <Clock className="w-4 h-4" />
                  <span>Opening Hours</span>
                </div>
                <div className="space-y-2.5 text-sm">
                  <div className="flex justify-between items-center text-[#FAF5EF]">
                    <span className="text-[#A89688]">Monday – Friday</span>
                    <span className="font-medium tabular-nums">8:00 AM – 10:00 PM</span>
                  </div>
                  <div className="flex justify-between items-center text-[#FAF5EF]">
                    <span className="text-[#A89688]">Saturday – Sunday</span>
                    <span className="font-medium text-[#E5C396] tabular-nums">9:00 AM – 11:00 PM</span>
                  </div>
                </div>
                <div className="mt-3 flex items-center gap-2 text-[11px] text-emerald-400">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Espresso bar & hearth bakery currently open</span>
                </div>
              </div>

              {/* Direct Communications */}
              <div className="pt-6 border-t border-[#2C1F19] space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-3 text-[#FAF5EF]">
                    <Phone className="w-4 h-4 text-[#C89B66]" />
                    <span className="font-mono text-xs">+1 (555) 234-8900</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => copyToClipboard('+1 (555) 234-8900', 'phone')}
                    className="text-xs text-[#C89B66] hover:underline"
                  >
                    {copiedContact === 'phone' ? 'Copied' : 'Copy'}
                  </button>
                </div>

                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-3 text-[#FAF5EF]">
                    <Mail className="w-4 h-4 text-[#C89B66]" />
                    <span className="text-xs">hello@auracafe.com</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => copyToClipboard('hello@auracafe.com', 'email')}
                    className="text-xs text-[#C89B66] hover:underline"
                  >
                    {copiedContact === 'email' ? 'Copied' : 'Copy'}
                  </button>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="pt-8 mt-6 border-t border-[#2C1F19] flex gap-3">
              <a
                href="https://maps.google.com"
                target="_blank"
                rel="noreferrer"
                className="flex-1 py-3 px-4 rounded-lg bg-[#271D18] hover:bg-[#34261F] border border-[#3E2C22] text-xs font-semibold uppercase tracking-wider text-[#FAF5EF] text-center flex items-center justify-center gap-2 transition-colors"
              >
                <Navigation className="w-3.5 h-3.5 text-[#C89B66]" />
                <span>Get Directions</span>
              </a>
              <a
                href="tel:+15552348900"
                className="py-3 px-4 rounded-lg bg-[#C89B66] hover:bg-[#D7A873] text-[#120E0C] text-xs font-semibold uppercase tracking-wider flex items-center justify-center transition-colors"
              >
                Call Café
              </a>
            </div>
          </div>

          {/* Right Column: Stylized Interactive Map Canvas / Card */}
          <div className="lg:col-span-7 bg-[#1B1411] border border-[#34241C] rounded-2xl overflow-hidden shadow-2xl flex flex-col">
            {/* Map Header Toolbar */}
            <div className="px-6 py-3.5 bg-[#201713] border-b border-[#2E2019] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Compass className="w-4 h-4 text-[#C89B66]" />
                <span className="text-xs font-medium text-[#FAF5EF] uppercase tracking-wider">
                  Interactive City Map
                </span>
              </div>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => setActiveTab('map')}
                  className={`px-3 py-1 rounded text-xs transition-colors ${
                    activeTab === 'map' ? 'bg-[#C89B66] text-[#120E0C] font-semibold' : 'text-[#A89688] hover:text-white'
                  }`}
                >
                  Map View
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('transit')}
                  className={`px-3 py-1 rounded text-xs transition-colors ${
                    activeTab === 'transit' ? 'bg-[#C89B66] text-[#120E0C] font-semibold' : 'text-[#A89688] hover:text-white'
                  }`}
                >
                  Transit & Parking
                </button>
              </div>
            </div>

            {/* Map Graphical Content */}
            <div className="relative flex-1 min-h-[380px] bg-[#140F0D] flex items-center justify-center overflow-hidden p-6">
              {activeTab === 'map' ? (
                <div className="relative w-full h-full flex flex-col items-center justify-center">
                  {/* Stylized Architectural Street Grid Graphic */}
                  <svg className="absolute inset-0 w-full h-full opacity-30" xmlns="http://www.w3.org/2000/svg">
                    <defs>
                      <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                        <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#4A3529" strokeWidth="1" />
                      </pattern>
                    </defs>
                    <rect width="100%" height="100%" fill="url(#grid)" />
                    {/* Main avenues */}
                    <line x1="0" y1="50%" x2="100%" y2="50%" stroke="#C89B66" strokeWidth="2.5" opacity="0.6" />
                    <line x1="50%" y1="0" x2="50%" y2="100%" stroke="#C89B66" strokeWidth="2.5" opacity="0.6" />
                    {/* River / Park curve */}
                    <path d="M 0,200 Q 250,120 500,280 T 1000,180" fill="none" stroke="#2D4336" strokeWidth="16" opacity="0.5" />
                  </svg>

                  {/* Street Labels */}
                  <div className="absolute top-[46%] left-6 text-[10px] tracking-widest uppercase text-[#9E8B7E] font-mono pointer-events-none">
                    Coffee Street Blvd
                  </div>
                  <div className="absolute top-8 left-[51%] text-[10px] tracking-widest uppercase text-[#9E8B7E] font-mono pointer-events-none">
                    Central Heritage Ave
                  </div>

                  {/* Custom Aura Pin */}
                  <div className="relative z-10 flex flex-col items-center animate-bounce">
                    <div className="px-3.5 py-1.5 rounded-lg bg-[#C89B66] text-[#120E0C] text-xs font-bold uppercase tracking-wider shadow-2xl flex items-center gap-1.5">
                      <span>✦</span>
                      <span>AURA CAFÉ</span>
                    </div>
                    <div className="w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-t-[8px] border-t-[#C89B66]" />
                    <div className="w-4 h-1.5 rounded-full bg-black/60 blur-[1px] mt-0.5" />
                  </div>

                  {/* Nearby Landmark Callouts */}
                  <div className="absolute bottom-6 left-6 p-3 rounded-lg bg-[#1B1411]/90 backdrop-blur-md border border-[#34241C] text-[11px] text-[#C5B5A6] max-w-xs shadow-lg">
                    <span className="font-semibold text-[#FAF5EF] block mb-0.5">District Landmark</span>
                    Directly opposite the Royal Conservatory Gardens, 2 mins walk from Grand Plaza Fountain.
                  </div>
                </div>
              ) : (
                <div className="w-full max-w-md space-y-4 py-4 z-10 text-left">
                  <div className="p-4 rounded-xl bg-[#1E1612] border border-[#34241C]">
                    <h4 className="text-xs uppercase tracking-wider text-[#C89B66] font-semibold mb-1">
                      Metro & Light Rail
                    </h4>
                    <p className="text-xs text-[#C5B5A6]">
                      Take the Green or Amber line to <strong>Central Plaza Station</strong> (Exit 3). Walk 180 meters east along Coffee Street.
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-[#1E1612] border border-[#34241C]">
                    <h4 className="text-xs uppercase tracking-wider text-[#C89B66] font-semibold mb-1">
                      Guest Valet & Parking
                    </h4>
                    <p className="text-xs text-[#C5B5A6]">
                      Complimentary 2-hour validated parking at the Conservatory Underground Garage (125 Coffee Street).
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-[#1E1612] border border-[#34241C]">
                    <h4 className="text-xs uppercase tracking-wider text-[#C89B66] font-semibold mb-1">
                      Bicycle Racks
                    </h4>
                    <p className="text-xs text-[#C5B5A6]">
                      Dedicated brass bicycle racks located right by our outdoor terrace planter boxes.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
