import React, { useState, useEffect } from 'react';
import { Menu, X, ShoppingBag, Volume2, VolumeX, Sparkles } from 'lucide-react';

interface NavbarProps {
  onOpenReservation: () => void;
  onOpenCart: () => void;
  cartCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenReservation,
  onOpenCart,
  cartCount
}) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [ambientAudioPlaying, setAmbientAudioPlaying] = useState(false);
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Ambient acoustic café sound synthesis (warm vinyl coffeehouse tone)
  const toggleAmbientSound = () => {
    if (!ambientAudioPlaying) {
      try {
        const ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
        
        // Soft brown noise generator for coffeehouse ambience warmth
        const bufferSize = ctx.sampleRate * 2;
        const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const data = buffer.getChannelData(0);
        let lastOut = 0.0;
        for (let i = 0; i < bufferSize; i++) {
          const white = Math.random() * 2 - 1;
          data[i] = (lastOut + (0.02 * white)) / 1.02;
          lastOut = data[i];
          data[i] *= 0.04; // Gentle quiet murmur
        }

        const noise = ctx.createBufferSource();
        noise.buffer = buffer;
        noise.loop = true;

        const filter = ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(450, ctx.currentTime);

        const gainNode = ctx.createGain();
        gainNode.gain.setValueAtTime(0.3, ctx.currentTime);

        noise.connect(filter);
        filter.connect(gainNode);
        gainNode.connect(ctx.destination);

        noise.start(0);
        setAudioContext(ctx);
        setAmbientAudioPlaying(true);
      } catch {
        // graceful fallback if blocked by browser policy
        setAmbientAudioPlaying(false);
      }
    } else {
      if (audioContext) {
        audioContext.close();
        setAudioContext(null);
      }
      setAmbientAudioPlaying(false);
    }
  };

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Menu', href: '#menu' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Our Story', href: '#story' },
    { name: 'Reviews', href: '#reviews' },
    { name: 'Contact', href: '#contact' }
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? 'bg-[#120E0C]/90 backdrop-blur-md border-b border-[#362720]/80 shadow-2xl py-3.5'
            : 'bg-gradient-to-b from-[#120E0C]/80 via-[#120E0C]/30 to-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Zone 1: Single text element wordmark */}
            <a
              href="#home"
              className="text-2xl sm:text-3xl font-serif tracking-widest text-[#F5EDE4] hover:text-[#C89B66] transition-colors flex items-center gap-2 group"
            >
              <span className="text-[#C89B66] text-xl transition-transform duration-300 group-hover:rotate-12">✦</span>
              <span>AURA CAFÉ</span>
            </a>

            {/* Zone 2: Clean text navigation links */}
            <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-[#CBB9A9]">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className="transition-colors hover:text-[#EADBCC] tracking-wide relative py-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[1.5px] after:bg-[#C89B66] hover:after:w-full after:transition-all after:duration-200"
                >
                  {link.name}
                </a>
              ))}
            </nav>

            {/* Zone 3: Actions (Ambient Audio, Cart, Book a Table) */}
            <div className="flex items-center gap-3">
              {/* Subtle Ambient Sound Toggle */}
              <button
                type="button"
                onClick={toggleAmbientSound}
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs text-[#CBB9A9] hover:text-[#F5EDE4] border border-[#3A2A22] rounded-md hover:border-[#C89B66]/60 transition-all"
                title={ambientAudioPlaying ? 'Mute café atmosphere sound' : 'Play subtle café ambience sound'}
                aria-label="Toggle café ambience sound"
              >
                {ambientAudioPlaying ? (
                  <>
                    <Volume2 className="w-3.5 h-3.5 text-[#C89B66]" />
                    <span className="whitespace-nowrap">Ambience On</span>
                  </>
                ) : (
                  <>
                    <VolumeX className="w-3.5 h-3.5 text-[#8A7569]" />
                    <span className="whitespace-nowrap">Ambience</span>
                  </>
                )}
              </button>

              {/* Cart Drawer Trigger */}
              <button
                type="button"
                onClick={onOpenCart}
                className="relative p-2.5 text-[#EADBCC] hover:text-[#C89B66] transition-colors rounded-full hover:bg-[#251B16] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C89B66]"
                aria-label="View order bag"
              >
                <ShoppingBag className="w-5 h-5" />
                {cartCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-5 h-5 bg-[#C89B66] text-[#120E0C] text-[11px] font-bold rounded-full flex items-center justify-center tabular-nums shadow-md animate-scaleIn">
                    {cartCount}
                  </span>
                )}
              </button>

              {/* Book a Table Primary CTA */}
              <button
                type="button"
                onClick={onOpenReservation}
                className="hidden sm:inline-flex items-center justify-center px-4 py-2 text-xs font-semibold uppercase tracking-wider text-[#120E0C] bg-gradient-to-r from-[#D7A873] via-[#C89B66] to-[#B38753] hover:from-[#E4BA87] hover:to-[#C89B66] rounded-md transition-all shadow-md hover:shadow-[#C89B66]/20 whitespace-nowrap active:scale-[0.98]"
              >
                Book a Table
              </button>

              {/* Mobile Hamburger Button */}
              <button
                type="button"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2 text-[#EADBCC] hover:text-[#C89B66] rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C89B66]"
                aria-label="Toggle mobile menu"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-sm"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="fixed top-0 right-0 bottom-0 w-72 max-w-[85vw] bg-[#17120F] border-l border-[#362720] p-6 shadow-2xl flex flex-col justify-between overflow-y-auto">
            <div>
              <div className="flex items-center justify-between pb-6 border-b border-[#2C1F19]">
                <span className="text-xl font-serif tracking-widest text-[#F5EDE4] flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#C89B66]" />
                  AURA CAFÉ
                </span>
                <button
                  type="button"
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-1.5 text-[#A89485] hover:text-white"
                  aria-label="Close menu"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <nav className="flex flex-col gap-4 mt-6">
                {navLinks.map((link) => (
                  <a
                    key={link.name}
                    href={link.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className="text-base font-medium text-[#D5C4B4] hover:text-[#C89B66] py-1 border-b border-[#251A15] transition-colors"
                  >
                    {link.name}
                  </a>
                ))}
              </nav>

              <div className="mt-6 pt-4 border-t border-[#2C1F19] flex items-center justify-between">
                <span className="text-xs text-[#8A7569]">Café Ambience Audio</span>
                <button
                  type="button"
                  onClick={toggleAmbientSound}
                  className="text-xs text-[#C89B66] underline font-medium"
                >
                  {ambientAudioPlaying ? 'Mute' : 'Play Sound'}
                </button>
              </div>
            </div>

            <div className="pt-8 border-t border-[#2C1F19] space-y-3">
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenReservation();
                }}
                className="w-full py-3 text-center text-xs font-semibold uppercase tracking-wider text-[#120E0C] bg-[#C89B66] hover:bg-[#D7A873] rounded-md transition-colors"
              >
                Book a Table
              </button>
              <p className="text-[11px] text-center text-[#8A7569]">
                123 Coffee Street · Open Today until 10:00 PM
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
