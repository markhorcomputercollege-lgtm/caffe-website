import React, { useState } from 'react';
import { Calendar, Clock, Users, CheckCircle, Sparkles, AlertCircle, Phone, Mail, User } from 'lucide-react';
import { ReservationData } from '../types/cafe';

interface ReservationProps {
  onSuccess?: (res: ReservationData) => void;
}

export const Reservation: React.FC<ReservationProps> = ({ onSuccess }) => {
  // Form State
  const [formData, setFormData] = useState<ReservationData>({
    fullName: '',
    email: '',
    phone: '',
    date: new Date().toISOString().split('T')[0],
    time: '18:30',
    guests: 2,
    seatingArea: 'Cozy Lounge',
    specialRequest: ''
  });

  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [confirmedReservation, setConfirmedReservation] = useState<{
    data: ReservationData;
    refCode: string;
  } | null>(null);

  const timeSlots = [
    '08:30', '09:30', '10:30', '11:30', '12:30',
    '14:00', '15:30', '17:00', '18:30', '20:00', '21:00'
  ];

  const seatingOptions = [
    'Cozy Lounge',
    'Window Nook',
    'Main Dining Room',
    'Outdoor Garden Terrace',
    'Espresso Bar Counter'
  ];

  const validate = () => {
    const newErrors: { [key: string]: string } = {};

    if (!formData.fullName.trim()) {
      newErrors.fullName = 'Full Name is required.';
    } else if (formData.fullName.trim().length < 2) {
      newErrors.fullName = 'Please enter a valid full name.';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Email address is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please provide a valid email address.';
    }

    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required.';
    } else if (formData.phone.trim().length < 7) {
      newErrors.phone = 'Please provide a valid contact number.';
    }

    if (!formData.date) {
      newErrors.date = 'Please select a date.';
    }

    if (!formData.time) {
      newErrors.time = 'Please select a reservation time.';
    }

    if (!formData.guests || formData.guests < 1 || formData.guests > 12) {
      newErrors.guests = 'Guests must be between 1 and 12.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validate()) return;

    setIsSubmitting(true);

    // Simulate luxury instant booking verification
    setTimeout(() => {
      const refCode = `AUR-${Math.floor(1000 + Math.random() * 9000)}`;
      setConfirmedReservation({
        data: { ...formData },
        refCode
      });
      setIsSubmitting(false);

      if (onSuccess) {
        onSuccess(formData);
      }
    }, 600);
  };

  const handleReset = () => {
    setConfirmedReservation(null);
    setFormData({
      fullName: '',
      email: '',
      phone: '',
      date: new Date().toISOString().split('T')[0],
      time: '18:30',
      guests: 2,
      seatingArea: 'Cozy Lounge',
      specialRequest: ''
    });
  };

  const todayStr = new Date().toISOString().split('T')[0];

  return (
    <section id="reservation" className="py-24 sm:py-32 bg-[#120E0C] relative">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-[#C89B66] font-medium mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Table Reservations</span>
          </div>
          <h2 className="text-4xl sm:text-5xl font-serif text-[#FAF5EF] tracking-tight leading-tight mb-4">
            Book Your Table
          </h2>
          <p className="text-base text-[#B5A496] font-light">
            Reserve your quiet corner for morning breakfast, an afternoon meeting, or an intimate evening gathering.
          </p>
        </div>

        {/* Confirmation State or Form */}
        {confirmedReservation ? (
          <div className="bg-[#1B1411] border border-[#3E2D22] rounded-2xl p-8 sm:p-12 shadow-2xl text-center space-y-6 animate-fadeIn">
            <div className="w-16 h-16 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto shadow-lg">
              <CheckCircle className="w-8 h-8" />
            </div>

            <div>
              <span className="text-xs uppercase tracking-widest text-[#C89B66] font-semibold">
                Reservation Confirmed
              </span>
              <h3 className="text-3xl font-serif text-[#FAF5EF] mt-1 mb-2">
                We Look Forward to Welcoming You
              </h3>
              <p className="text-xs sm:text-sm text-[#A89688]">
                A confirmation has been sent to{' '}
                <strong className="text-[#FAF5EF] font-medium">{confirmedReservation.data.email}</strong>.
              </p>
            </div>

            {/* Reservation Summary Details */}
            <div className="max-w-md mx-auto p-6 bg-[#221915] rounded-xl border border-[#362720] text-left space-y-3">
              <div className="flex justify-between items-center pb-2 border-b border-[#2E2019]">
                <span className="text-xs text-[#9E8B7E]">Confirmation Code</span>
                <span className="text-sm font-mono font-bold text-[#E5C396] tracking-wider">
                  {confirmedReservation.refCode}
                </span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-[#9E8B7E]">Guest Name</span>
                <span className="font-medium text-[#FAF5EF]">{confirmedReservation.data.fullName}</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-[#9E8B7E]">Date & Time</span>
                <span className="font-medium text-[#FAF5EF]">
                  {confirmedReservation.data.date} at {confirmedReservation.data.time}
                </span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-[#9E8B7E]">Party Size</span>
                <span className="font-medium text-[#FAF5EF]">
                  {confirmedReservation.data.guests} {confirmedReservation.data.guests === 1 ? 'Guest' : 'Guests'}
                </span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-[#9E8B7E]">Seating Area</span>
                <span className="font-medium text-[#FAF5EF]">{confirmedReservation.data.seatingArea}</span>
              </div>
              {confirmedReservation.data.specialRequest && (
                <div className="pt-2 border-t border-[#2E2019] text-xs">
                  <span className="text-[#9E8B7E] block mb-0.5">Special Notes</span>
                  <span className="text-[#C5B5A6] italic">{confirmedReservation.data.specialRequest}</span>
                </div>
              )}
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={handleReset}
                className="px-6 py-2.5 text-xs font-semibold uppercase tracking-wider text-[#FAF5EF] bg-[#2A1E19] hover:bg-[#382821] border border-[#48342B] rounded-md transition-colors"
              >
                Make Another Reservation
              </button>
            </div>
          </div>
        ) : (
          <form
            onSubmit={handleSubmit}
            noValidate
            className="bg-[#18120F] border border-[#32231A] rounded-2xl p-6 sm:p-10 shadow-2xl space-y-6"
          >
            {/* Primary Guest Info */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#9E8B7E] mb-1.5 font-medium">
                  Full Name *
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-[#7A695E] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    placeholder="Eleanor Vance"
                    className={`w-full pl-10 pr-3.5 py-2.5 rounded-lg bg-[#211814] border text-sm text-[#FAF5EF] placeholder-[#6E5B4F] focus:outline-none transition-colors ${
                      errors.fullName ? 'border-red-500/80' : 'border-[#38271F] focus:border-[#C89B66]'
                    }`}
                  />
                </div>
                {errors.fullName && (
                  <p className="text-[11px] text-red-400 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {errors.fullName}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-[#9E8B7E] mb-1.5 font-medium">
                  Email *
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-[#7A695E] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="eleanor@domain.com"
                    className={`w-full pl-10 pr-3.5 py-2.5 rounded-lg bg-[#211814] border text-sm text-[#FAF5EF] placeholder-[#6E5B4F] focus:outline-none transition-colors ${
                      errors.email ? 'border-red-500/80' : 'border-[#38271F] focus:border-[#C89B66]'
                    }`}
                  />
                </div>
                {errors.email && (
                  <p className="text-[11px] text-red-400 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {errors.email}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-[#9E8B7E] mb-1.5 font-medium">
                  Phone *
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-[#7A695E] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="+1 (555) 329-8472"
                    className={`w-full pl-10 pr-3.5 py-2.5 rounded-lg bg-[#211814] border text-sm text-[#FAF5EF] placeholder-[#6E5B4F] focus:outline-none transition-colors ${
                      errors.phone ? 'border-red-500/80' : 'border-[#38271F] focus:border-[#C89B66]'
                    }`}
                  />
                </div>
                {errors.phone && (
                  <p className="text-[11px] text-red-400 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {errors.phone}
                  </p>
                )}
              </div>
            </div>

            {/* Date, Time, Guests */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#9E8B7E] mb-1.5 font-medium">
                  Date *
                </label>
                <div className="relative">
                  <Calendar className="w-4 h-4 text-[#7A695E] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="date"
                    min={todayStr}
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-lg bg-[#211814] border border-[#38271F] text-sm text-[#FAF5EF] focus:outline-none focus:border-[#C89B66]"
                  />
                </div>
                {errors.date && (
                  <p className="text-[11px] text-red-400 mt-1">{errors.date}</p>
                )}
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-[#9E8B7E] mb-1.5 font-medium">
                  Time *
                </label>
                <div className="relative">
                  <Clock className="w-4 h-4 text-[#7A695E] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <select
                    value={formData.time}
                    onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-lg bg-[#211814] border border-[#38271F] text-sm text-[#FAF5EF] focus:outline-none focus:border-[#C89B66]"
                  >
                    {timeSlots.map((slot) => (
                      <option key={slot} value={slot} className="bg-[#211814] text-[#FAF5EF]">
                        {slot}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-[#9E8B7E] mb-1.5 font-medium">
                  Number of Guests *
                </label>
                <div className="relative">
                  <Users className="w-4 h-4 text-[#7A695E] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <select
                    value={formData.guests}
                    onChange={(e) => setFormData({ ...formData, guests: parseInt(e.target.value, 10) })}
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-lg bg-[#211814] border border-[#38271F] text-sm text-[#FAF5EF] focus:outline-none focus:border-[#C89B66]"
                  >
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12].map((num) => (
                      <option key={num} value={num} className="bg-[#211814] text-[#FAF5EF]">
                        {num} {num === 1 ? 'Guest' : 'Guests'}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Seating Area Preference */}
            <div>
              <label className="block text-xs uppercase tracking-wider text-[#9E8B7E] mb-2 font-medium">
                Preferred Seating Area
              </label>
              <div className="flex flex-wrap gap-2">
                {seatingOptions.map((area) => (
                  <button
                    key={area}
                    type="button"
                    onClick={() => setFormData({ ...formData, seatingArea: area })}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                      formData.seatingArea === area
                        ? 'bg-[#C89B66] text-[#120E0C] font-semibold'
                        : 'bg-[#211814] text-[#C5B5A6] border border-[#38271F] hover:border-[#C89B66]/40'
                    }`}
                  >
                    {area}
                  </button>
                ))}
              </div>
            </div>

            {/* Special Request */}
            <div>
              <label className="block text-xs uppercase tracking-wider text-[#9E8B7E] mb-1.5 font-medium">
                Special Request (Optional)
              </label>
              <textarea
                rows={3}
                value={formData.specialRequest}
                onChange={(e) => setFormData({ ...formData, specialRequest: e.target.value })}
                placeholder="Anniversary, dietary restrictions, quiet corner for business meeting, high chair..."
                className="w-full px-3.5 py-2.5 rounded-lg bg-[#211814] border border-[#38271F] text-sm text-[#FAF5EF] placeholder-[#6E5B4F] focus:outline-none focus:border-[#C89B66]"
              />
            </div>

            {/* Submit Button */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-4 text-xs sm:text-sm font-semibold uppercase tracking-widest text-[#120E0C] bg-gradient-to-r from-[#D7A873] via-[#C89B66] to-[#B38753] hover:from-[#E4BA87] hover:to-[#C89B66] rounded-md transition-all shadow-xl active:scale-[0.99] cursor-pointer disabled:opacity-50"
              >
                {isSubmitting ? 'Confirming Availability...' : 'RESERVE MY TABLE'}
              </button>
            </div>

            <p className="text-[11px] text-center text-[#786457]">
              Tables are held for 15 minutes past reservation time. No deposit required.
            </p>
          </form>
        )}
      </div>
    </section>
  );
};
