import React, { useState, useEffect } from 'react';
import { Star, ChevronLeft, ChevronRight, Quote, Plus, Sparkles, Check, X } from 'lucide-react';
import { ReviewItem } from '../types/cafe';
import { REVIEWS } from '../data/cafeData';

export const ReviewsCarousel: React.FC = () => {
  const [reviews, setReviews] = useState<ReviewItem[]>(REVIEWS);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);

  // New review form state
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState('Coffee Enthusiast');
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState('');
  const [submittedFeedback, setSubmittedFeedback] = useState(false);

  // Autoplay carousel every 6 seconds if not hovered
  useEffect(() => {
    if (isPaused || modalOpen) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % reviews.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [reviews.length, isPaused, modalOpen]);

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + reviews.length) % reviews.length);
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % reviews.length);
  };

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newComment.trim()) return;

    const newRev: ReviewItem = {
      id: Date.now().toString(),
      name: newName.trim(),
      role: newRole.trim() || 'Verified Guest',
      rating: newRating,
      comment: newComment.trim(),
      date: 'Just now'
    };

    setReviews([newRev, ...reviews]);
    setCurrentIndex(0);
    setSubmittedFeedback(true);

    setTimeout(() => {
      setSubmittedFeedback(false);
      setModalOpen(false);
      setNewName('');
      setNewComment('');
    }, 1500);
  };

  const currentReview = reviews[currentIndex];

  return (
    <section
      id="reviews"
      className="py-24 sm:py-32 bg-[#16110E] relative overflow-hidden"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-[#C89B66] font-medium mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Honored Guests</span>
          </div>
          <h2 className="text-4xl sm:text-5xl font-serif text-[#FAF5EF] tracking-tight leading-tight mb-4">
            Customer Stories
          </h2>
          <p className="text-base text-[#B5A496] font-light">
            Reflections and words of kindness from coffee lovers, morning regulars, and travellers.
          </p>
        </div>

        {/* Carousel Slide Card */}
        <div className="relative bg-[#1E1612] border border-[#3A2A20] rounded-2xl p-8 sm:p-12 shadow-2xl transition-all duration-500 min-h-[320px] flex flex-col justify-between">
          {/* Subtle Ambient Quote Graphic */}
          <Quote className="w-16 h-16 text-[#C89B66]/15 absolute top-6 right-8 pointer-events-none" />

          {/* Review Body */}
          <div className="relative z-10">
            {/* Star Rating */}
            <div className="flex items-center gap-1 mb-6">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-4 h-4 ${
                    i < currentReview.rating
                      ? 'text-[#C89B66] fill-[#C89B66]'
                      : 'text-[#443329]'
                  }`}
                />
              ))}
              <span className="ml-2 text-xs text-[#A89688] font-mono">
                {currentReview.rating}.0 / 5.0
              </span>
            </div>

            {/* Quote text */}
            <blockquote className="text-xl sm:text-2xl lg:text-3xl font-serif italic text-[#FAF5EF] font-light leading-relaxed mb-8">
              “{currentReview.comment}”
            </blockquote>
          </div>

          {/* Author info & navigation controls */}
          <div className="relative z-10 pt-6 border-t border-[#2F2119] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h4 className="text-lg font-serif font-medium text-[#FAF5EF]">
                {currentReview.name}
              </h4>
              <p className="text-xs text-[#A89688]">
                {currentReview.role} · <span className="text-[#786457]">{currentReview.date}</span>
              </p>
            </div>

            {/* Slider Navigation Buttons */}
            <div className="flex items-center gap-3 self-end sm:self-center">
              <button
                type="button"
                onClick={handlePrev}
                className="p-2.5 rounded-full bg-[#271E19] hover:bg-[#C89B66] text-[#C5B5A6] hover:text-[#120E0C] border border-[#3A2A20] transition-colors cursor-pointer"
                aria-label="Previous review"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>

              {/* Progress Dots */}
              <div className="flex items-center gap-1.5 px-2">
                {reviews.map((_, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setCurrentIndex(idx)}
                    className={`h-1.5 rounded-full transition-all cursor-pointer ${
                      idx === currentIndex ? 'w-6 bg-[#C89B66]' : 'w-2 bg-[#3A2A20] hover:bg-[#5C4538]'
                    }`}
                    aria-label={`Go to slide ${idx + 1}`}
                  />
                ))}
              </div>

              <button
                type="button"
                onClick={handleNext}
                className="p-2.5 rounded-full bg-[#271E19] hover:bg-[#C89B66] text-[#C5B5A6] hover:text-[#120E0C] border border-[#3A2A20] transition-colors cursor-pointer"
                aria-label="Next review"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Action Button: Share your experience */}
        <div className="mt-10 text-center">
          <button
            type="button"
            onClick={() => setModalOpen(true)}
            className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-[#FAF5EF] bg-[#221914] hover:bg-[#2F2119] border border-[#3E2D22] hover:border-[#C89B66] rounded-md transition-all cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5 text-[#C89B66]" />
            <span>Leave a Review</span>
          </button>
        </div>
      </div>

      {/* Leave a Review Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-lg bg-[#1C1512] border border-[#3E2D23] rounded-xl p-6 sm:p-8 shadow-2xl text-[#EADBCC]">
            <div className="flex items-center justify-between pb-4 border-b border-[#2C1F19] mb-5">
              <h3 className="text-xl font-serif text-[#FAF5EF]">Share Your Experience</h3>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="text-[#9E8B7E] hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {submittedFeedback ? (
              <div className="py-8 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mx-auto">
                  <Check className="w-6 h-6" />
                </div>
                <h4 className="text-xl font-serif text-[#FAF5EF]">Thank You For Your Review!</h4>
                <p className="text-xs text-[#A89688]">Your story has been added to our guestbook.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmitReview} className="space-y-4">
                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#9E8B7E] mb-1.5 font-medium">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="e.g. Clara Oswald"
                    className="w-full px-3.5 py-2.5 rounded-lg bg-[#241A16] border border-[#3E2D23] text-sm text-[#FAF5EF] placeholder-[#786457] focus:outline-none focus:border-[#C89B66]"
                  />
                </div>

                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#9E8B7E] mb-1.5 font-medium">
                    Your Role / Context
                  </label>
                  <input
                    type="text"
                    value={newRole}
                    onChange={(e) => setNewRole(e.target.value)}
                    placeholder="e.g. Morning Regular, Designer, Traveler"
                    className="w-full px-3.5 py-2.5 rounded-lg bg-[#241A16] border border-[#3E2D23] text-sm text-[#FAF5EF] placeholder-[#786457] focus:outline-none focus:border-[#C89B66]"
                  />
                </div>

                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#9E8B7E] mb-1.5 font-medium">
                    Rating
                  </label>
                  <div className="flex items-center gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setNewRating(star)}
                        className="p-1 cursor-pointer"
                      >
                        <Star
                          className={`w-6 h-6 ${
                            star <= newRating
                              ? 'text-[#C89B66] fill-[#C89B66]'
                              : 'text-[#443329]'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#9E8B7E] mb-1.5 font-medium">
                    Your Review *
                  </label>
                  <textarea
                    required
                    rows={4}
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Tell us about the coffee, pastry, atmosphere, or service..."
                    className="w-full px-3.5 py-2.5 rounded-lg bg-[#241A16] border border-[#3E2D23] text-sm text-[#FAF5EF] placeholder-[#786457] focus:outline-none focus:border-[#C89B66]"
                  />
                </div>

                <div className="pt-2 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setModalOpen(false)}
                    className="px-4 py-2 text-xs text-[#9E8B7E] hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2.5 text-xs font-semibold uppercase tracking-wider text-[#120E0C] bg-[#C89B66] hover:bg-[#D7A873] rounded-md transition-colors"
                  >
                    Submit Story
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </section>
  );
};
