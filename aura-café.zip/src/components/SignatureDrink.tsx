import React, { useState } from 'react';
import { Sparkles, ShoppingBag, Check } from 'lucide-react';
import signatureImg from '../assets/images/signature_caramel_latte_1790920452310.jpg';
import { MenuItem } from '../types/cafe';

interface SignatureDrinkProps {
  onAddToCart: (item: MenuItem, optionDetails?: string) => void;
}

export const SignatureDrink: React.FC<SignatureDrinkProps> = ({ onAddToCart }) => {
  const [temperature, setTemperature] = useState<'Hot' | 'Iced'>('Hot');
  const [milkOption, setMilkOption] = useState<'Whole Milk' | 'Oat Milk' | 'Almond Milk'>('Oat Milk');
  const [ordered, setOrdered] = useState(false);

  const handleOrder = () => {
    const signatureDrinkItem: MenuItem = {
      id: 'signature-caramel-latte-special',
      name: `Signature Caramel Latte (${temperature})`,
      category: 'Coffee',
      price: 6.00,
      description: `Smooth espresso, creamy ${milkOption}, and house-simmered Madagascar vanilla caramel.`,
      image: signatureImg,
      popular: true
    };

    onAddToCart(signatureDrinkItem, `${temperature} · ${milkOption}`);
    setOrdered(true);
    setTimeout(() => setOrdered(false), 2000);
  };

  return (
    <section className="py-24 sm:py-32 bg-[#17110E] relative overflow-hidden">
      {/* Ambient background glow */}
      <div className="absolute top-1/2 right-1/4 w-[450px] h-[450px] bg-[#C89B66]/10 rounded-full blur-[100px] pointer-events-none -translate-y-1/2" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Visual with Steam Effect */}
          <div className="lg:col-span-6 flex justify-center order-2 lg:order-1">
            <div className="relative w-full max-w-md sm:max-w-lg aspect-square">
              {/* Outer decorative ring */}
              <div className="absolute -inset-4 rounded-full border border-[#C89B66]/20 animate-[spin_60s_linear_infinite]" />

              {/* Main Image Container */}
              <div className="relative w-full h-full rounded-2xl overflow-hidden border border-[#433127] shadow-2xl bg-[#201713] glow-gold">
                <img
                  src={signatureImg}
                  alt="Aura Café Signature Caramel Latte with golden foam art"
                  className="w-full h-full object-cover object-center scale-100 hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />

                {/* Animated Steam Clouds rising from the cup */}
                <div className="absolute top-6 left-1/2 -translate-x-1/2 w-32 h-32 pointer-events-none z-20">
                  <div className="absolute left-6 bottom-0 w-8 h-16 bg-white/20 blur-md rounded-full animate-steam-1" />
                  <div className="absolute left-14 bottom-0 w-10 h-20 bg-white/25 blur-lg rounded-full animate-steam-2" />
                  <div className="absolute left-20 bottom-0 w-7 h-14 bg-white/15 blur-md rounded-full animate-steam-3" />
                </div>

                {/* Price Callout Tag inside image */}
                <div className="absolute bottom-6 right-6 px-4 py-2 bg-[#120E0C]/90 backdrop-blur-md border border-[#C89B66]/50 rounded-lg shadow-lg">
                  <span className="text-[10px] text-[#A89688] uppercase tracking-wider block">Price</span>
                  <span className="text-xl font-serif font-bold text-[#E5C396] tabular-nums">$6.00</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Drink Narrative & Customizer */}
          <div className="lg:col-span-6 flex flex-col justify-center order-1 lg:order-2">
            <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-[#C89B66] font-medium mb-3">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Café Masterpiece</span>
            </div>

            <h2 className="text-4xl sm:text-5xl font-serif text-[#FAF5EF] tracking-tight leading-tight mb-4">
              Meet Our Signature Latte
            </h2>

            <p className="text-xl sm:text-2xl font-serif italic text-[#D8B998] font-normal mb-6">
              “Smooth espresso, creamy milk and our house-made caramel blend.”
            </p>

            <p className="text-base text-[#B5A496] font-light leading-relaxed mb-8">
              We simmer our caramel syrup in-house every morning using organic raw cane sugar, Madagascar Bourbon vanilla pods, and a pinch of Cornish sea salt. Poured through a velvety microfoam layer over a double shot of washed Ethiopian Sidama espresso.
            </p>

            {/* Flavor Tasting Notes */}
            <div className="p-4 rounded-xl bg-[#201814] border border-[#382820] mb-8">
              <span className="text-xs uppercase tracking-wider text-[#A89688] block mb-2 font-medium">
                Sensory Profile
              </span>
              <div className="flex flex-wrap gap-2 text-xs text-[#E5C396]">
                <span className="px-3 py-1 bg-[#2C1F19] rounded-md border border-[#433127]">Salted Honeycomb</span>
                <span className="px-3 py-1 bg-[#2C1F19] rounded-md border border-[#433127]">Dark Cocoa Butter</span>
                <span className="px-3 py-1 bg-[#2C1F19] rounded-md border border-[#433127]">Toasted Macadamia</span>
              </div>
            </div>

            {/* Interactive Options */}
            <div className="space-y-4 mb-8">
              {/* Temperature Selector */}
              <div>
                <label className="text-xs uppercase tracking-wider text-[#9E8B7E] block mb-2 font-medium">
                  Preparation Style
                </label>
                <div className="flex items-center gap-2">
                  {(['Hot', 'Iced'] as const).map((temp) => (
                    <button
                      key={temp}
                      type="button"
                      onClick={() => setTemperature(temp)}
                      className={`px-4 py-2 text-xs font-medium rounded-lg transition-all cursor-pointer ${
                        temperature === temp
                          ? 'bg-[#C89B66] text-[#120E0C] font-semibold shadow'
                          : 'bg-[#221A15] text-[#C5B5A6] border border-[#34241C] hover:border-[#C89B66]/50'
                      }`}
                    >
                      {temp === 'Hot' ? '☕ Hot (Steamed)' : '🧊 Over Artisan Ice'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Milk Selector */}
              <div>
                <label className="text-xs uppercase tracking-wider text-[#9E8B7E] block mb-2 font-medium">
                  Milk Preference
                </label>
                <div className="flex flex-wrap items-center gap-2">
                  {(['Oat Milk', 'Whole Milk', 'Almond Milk'] as const).map((milk) => (
                    <button
                      key={milk}
                      type="button"
                      onClick={() => setMilkOption(milk)}
                      className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer ${
                        milkOption === milk
                          ? 'bg-[#C89B66] text-[#120E0C] font-semibold shadow'
                          : 'bg-[#221A15] text-[#C5B5A6] border border-[#34241C] hover:border-[#C89B66]/50'
                      }`}
                    >
                      {milk}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Order Now Button */}
            <div>
              <button
                type="button"
                onClick={handleOrder}
                className={`inline-flex items-center gap-3 px-8 py-4 text-xs sm:text-sm font-semibold uppercase tracking-widest rounded-md transition-all shadow-xl active:scale-[0.98] cursor-pointer ${
                  ordered
                    ? 'bg-emerald-600 text-white'
                    : 'bg-gradient-to-r from-[#D7A873] via-[#C89B66] to-[#B38753] hover:from-[#E4BA87] hover:to-[#C89B66] text-[#120E0C]'
                }`}
              >
                {ordered ? (
                  <>
                    <Check className="w-5 h-5" />
                    <span>Added to Order</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-5 h-5" />
                    <span>Order Now — $6.00</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
