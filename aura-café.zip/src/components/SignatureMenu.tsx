import React, { useState, useMemo } from 'react';
import { Plus, Check, Sparkles, Filter } from 'lucide-react';
import { MenuCategory, MenuItem } from '../types/cafe';
import { MENU_ITEMS } from '../data/cafeData';

interface SignatureMenuProps {
  onAddToCart: (item: MenuItem) => void;
}

export const SignatureMenu: React.FC<SignatureMenuProps> = ({ onAddToCart }) => {
  const [selectedCategory, setSelectedCategory] = useState<MenuCategory>('All');
  const [dietaryFilter, setDietaryFilter] = useState<string>('All');
  const [addedItemIds, setAddedItemIds] = useState<{ [id: string]: boolean }>({});

  const categories: MenuCategory[] = ['All', 'Coffee', 'Breakfast', 'Desserts', 'Cakes', 'Cold Drinks'];

  const filteredItems = useMemo(() => {
    return MENU_ITEMS.filter((item) => {
      const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
      const matchesDietary = dietaryFilter === 'All' || (item.dietary && item.dietary.includes(dietaryFilter));
      return matchesCategory && matchesDietary;
    });
  }, [selectedCategory, dietaryFilter]);

  const handleAdd = (item: MenuItem) => {
    onAddToCart(item);
    setAddedItemIds((prev) => ({ ...prev, [item.id]: true }));
    setTimeout(() => {
      setAddedItemIds((prev) => ({ ...prev, [item.id]: false }));
    }, 1200);
  };

  return (
    <section id="menu" className="py-24 sm:py-32 bg-[#120E0C] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-[#C89B66] font-medium mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Curated Artisan Selection</span>
          </div>
          <h2 className="text-4xl sm:text-5xl font-serif text-[#FAF5EF] tracking-tight leading-tight mb-4">
            Signature Menu
          </h2>
          <p className="text-base text-[#B5A496] font-light">
            Every item is crafted with premium organic ingredients, ethical direct-trade coffee beans, and hearthside devotion.
          </p>
        </div>

        {/* Category Controls (Interactive Segmented Tabs) */}
        <div className="flex flex-col items-center gap-4 mb-12">
          {/* Main Category Bar */}
          <div className="flex items-center justify-start sm:justify-center gap-1.5 p-1.5 bg-[#1C1512] border border-[#34241C] rounded-xl max-w-full overflow-x-auto scrollbar-none">
            {categories.map((cat) => {
              const isActive = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-4 sm:px-5 py-2 text-xs sm:text-sm font-medium rounded-lg transition-all whitespace-nowrap cursor-pointer ${
                    isActive
                      ? 'bg-[#C89B66] text-[#120E0C] shadow-md font-semibold'
                      : 'text-[#C5B5A6] hover:text-[#FAF5EF] hover:bg-[#281D17]'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>

          {/* Quick Dietary Filter Sub-bar */}
          <div className="flex items-center gap-2 text-xs text-[#9E8B7E] pt-1">
            <Filter className="w-3 h-3 text-[#C89B66]" />
            <span>Dietary:</span>
            {['All', 'Vegetarian', 'Vegan', 'Gluten-Free'].map((diet) => (
              <button
                key={diet}
                type="button"
                onClick={() => setDietaryFilter(diet)}
                className={`px-2 py-0.5 rounded transition-colors ${
                  dietaryFilter === diet
                    ? 'text-[#C89B66] font-semibold underline underline-offset-4'
                    : 'text-[#8A7569] hover:text-[#C5B5A6]'
                }`}
              >
                {diet}
              </button>
            ))}
          </div>
        </div>

        {/* Menu Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {filteredItems.map((item) => {
            const isAdded = !!addedItemIds[item.id];
            return (
              <div
                key={item.id}
                className="group bg-[#191310] border border-[#30221A] hover:border-[#C89B66]/60 rounded-xl overflow-hidden shadow-lg transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl flex flex-col justify-between"
              >
                <div>
                  {/* Card Image */}
                  <div className="relative h-52 sm:h-56 w-full overflow-hidden bg-[#201814]">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#191310] via-transparent to-transparent opacity-80" />

                    {/* Unboxed category tag (Zero-Pill compliant) */}
                    <div className="absolute top-3.5 left-3.5 text-[11px] font-semibold uppercase tracking-wider text-[#FAF5EF] bg-[#120E0C]/80 backdrop-blur-md px-2.5 py-1 rounded">
                      {item.category}
                    </div>

                    {item.popular && (
                      <div className="absolute top-3.5 right-3.5 text-[10px] font-bold uppercase tracking-wider text-[#120E0C] bg-[#C89B66] px-2 py-0.5 rounded shadow">
                        Bestseller
                      </div>
                    )}
                  </div>

                  {/* Card Details */}
                  <div className="p-5 sm:p-6">
                    <div className="flex items-baseline justify-between gap-2 mb-2">
                      <h3 className="text-xl font-serif font-medium text-[#FAF5EF] group-hover:text-[#C89B66] transition-colors">
                        {item.name}
                      </h3>
                      <span className="text-base font-semibold text-[#E5C396] tabular-nums whitespace-nowrap">
                        ${item.price.toFixed(2)}
                      </span>
                    </div>

                    <p className="text-xs sm:text-sm text-[#A89688] font-light leading-relaxed mb-4 line-clamp-2">
                      {item.description}
                    </p>

                    {/* Subtle unboxed dietary notes */}
                    <div className="flex items-center gap-2 text-[11px] text-[#7E6C60]">
                      {item.calories && <span>{item.calories}</span>}
                      {item.dietary && item.dietary.length > 0 && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span>{item.dietary.join(' · ')}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Card Action */}
                <div className="px-5 sm:px-6 pb-5 pt-0">
                  <button
                    type="button"
                    onClick={() => handleAdd(item)}
                    className={`w-full py-2.5 px-4 text-xs font-semibold uppercase tracking-wider rounded-md flex items-center justify-center gap-2 transition-all cursor-pointer ${
                      isAdded
                        ? 'bg-emerald-700 text-white'
                        : 'bg-[#271D18] hover:bg-[#C89B66] text-[#EADBCC] hover:text-[#120E0C] border border-[#3E2D23] hover:border-[#C89B66]'
                    }`}
                  >
                    {isAdded ? (
                      <>
                        <Check className="w-4 h-4" />
                        <span>Added to Order</span>
                      </>
                    ) : (
                      <>
                        <Plus className="w-4 h-4" />
                        <span>Add to Order</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Note */}
        <div className="mt-12 text-center text-xs text-[#8A7569]">
          * Dairy-free alternatives (Oat, Almond) and decaf roasts available upon request with any barista.
        </div>
      </div>
    </section>
  );
};
