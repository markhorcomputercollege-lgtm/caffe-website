import React from 'react';
import { X, Award, Flame, Heart, Coffee } from 'lucide-react';
import aboutImg from '../assets/images/about_cafe_artisan_1790920440454.jpg';
import atmosphereImg from '../assets/images/cozy_cafe_atmosphere_1790920475942.jpg';

interface StoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenReservation: () => void;
}

export const StoryModal: React.FC<StoryModalProps> = ({
  isOpen,
  onClose,
  onOpenReservation
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-md transition-opacity"
        onClick={onClose}
      />

      {/* Modal Dialog */}
      <div className="relative z-10 w-full max-w-3xl bg-[#1A1412] border border-[#3E2E25] rounded-xl shadow-2xl overflow-hidden text-[#EADBCC] my-8 animate-fadeIn">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#2C201A] bg-[#15100E]">
          <span className="text-xs uppercase tracking-widest text-[#C89B66] font-semibold flex items-center gap-2">
            <Coffee className="w-3.5 h-3.5" />
            Our Heritage & Philosophy
          </span>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-[#9E8B7E] hover:text-[#FAF5EF] rounded-md transition-colors"
            aria-label="Close story dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Hero image in modal */}
        <div className="relative h-64 sm:h-72 w-full overflow-hidden">
          <img
            src={aboutImg}
            alt="Artisan barista crafting coffee"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#1A1412] via-transparent to-black/30" />
          <div className="absolute bottom-4 left-6">
            <p className="text-2xl sm:text-3xl font-serif text-[#FAF5EF]">
              Born From a Quiet Passion
            </p>
            <p className="text-xs text-[#C89B66] tracking-wider uppercase mt-1">
              Est. 2019 · City Center
            </p>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 space-y-6 text-sm leading-relaxed text-[#C5B5A6]">
          <p className="text-base text-[#FAF5EF] font-serif italic">
            “We started AURA CAFÉ with a very singular belief: that in a hurried world, coffee should not merely be fuel, but a pause of pure sanctuary.”
          </p>

          <p>
            Founded by head roaster Leo Vance and master pastry chef Clara Morandi, AURA was designed as a space where time slows down. Every batch of beans is ethically sourced directly from smallholder farms across Sidama and Huila, roasted on our custom 15kg cast-iron roaster to highlight each harvest's individual terroir.
          </p>

          {/* Three pillars */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
            <div className="p-4 rounded-lg bg-[#221B17] border border-[#33251E]">
              <div className="flex items-center gap-2 text-[#C89B66] font-medium text-xs uppercase mb-1">
                <Flame className="w-4 h-4" />
                <span>Micro Roasting</span>
              </div>
              <p className="text-xs text-[#A89688]">
                Small batches roasted twice weekly, ensuring maximum freshness and aromatic crema.
              </p>
            </div>

            <div className="p-4 rounded-lg bg-[#221B17] border border-[#33251E]">
              <div className="flex items-center gap-2 text-[#C89B66] font-medium text-xs uppercase mb-1">
                <Award className="w-4 h-4" />
                <span>Artisan Hearth</span>
              </div>
              <p className="text-xs text-[#A89688]">
                French butter laminated doughs fermented 48 hours for delicate honeycomb layers.
              </p>
            </div>

            <div className="p-4 rounded-lg bg-[#221B17] border border-[#33251E]">
              <div className="flex items-center gap-2 text-[#C89B66] font-medium text-xs uppercase mb-1">
                <Heart className="w-4 h-4" />
                <span>Slow Hospitality</span>
              </div>
              <p className="text-xs text-[#A89688]">
                Warm smiles, gentle acoustics, and an atmosphere welcoming both solo readers and old friends.
              </p>
            </div>
          </div>

          <div className="relative rounded-lg overflow-hidden border border-[#33251E] mt-4">
            <img
              src={atmosphereImg}
              alt="Cozy café corner"
              className="w-full h-44 object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#1A1412]/90 via-[#1A1412]/60 to-transparent p-6 flex flex-col justify-center max-w-md">
              <h4 className="text-lg font-serif text-[#FAF5EF]">Join Our Morning Table</h4>
              <p className="text-xs text-[#C8B8A9] mt-1">
                Freshly pulled espressos and warm croissants await you every morning from 8:00 AM.
              </p>
            </div>
          </div>
        </div>

        {/* Footer Action */}
        <div className="px-6 py-4 bg-[#15100E] border-t border-[#2C201A] flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-[#8A7569]">
            AURA CAFÉ · 123 Coffee Street
          </p>
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              type="button"
              onClick={onClose}
              className="w-full sm:w-auto px-4 py-2 text-xs text-[#B5A496] hover:text-white"
            >
              Close
            </button>
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenReservation();
              }}
              className="w-full sm:w-auto px-5 py-2 text-xs font-semibold uppercase tracking-wider text-[#120E0C] bg-[#C89B66] hover:bg-[#D7A873] rounded-md transition-colors whitespace-nowrap"
            >
              Reserve a Table
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
