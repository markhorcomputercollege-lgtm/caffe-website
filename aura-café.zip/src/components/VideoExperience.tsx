import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Volume2, VolumeX, Maximize, Upload, RefreshCw, Film, Sparkles } from 'lucide-react';
import heroBg from '../assets/images/hero_cafe_interior_1790920421286.jpg';

export const VideoExperience: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.7);
  const [isMuted, setIsMuted] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(65);
  const [customVideoUrl, setCustomVideoUrl] = useState<string | null>(null);
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Fallback ambient café reel (high-quality royalty-free coffee clip)
  const defaultReelUrl = 'https://assets.mixkit.co/videos/preview/mixkit-coffee-maker-pouring-fresh-coffee-in-a-cup-40542-large.mp4';

  const activeVideoSrc = customVideoUrl || defaultReelUrl;

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play().then(() => {
        setIsPlaying(true);
      }).catch(() => {
        setIsPlaying(false);
      });
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
      if (videoRef.current.duration) {
        setDuration(videoRef.current.duration);
      }
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    setCurrentTime(time);
    if (videoRef.current) {
      videoRef.current.currentTime = time;
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    if (videoRef.current) {
      videoRef.current.volume = val;
      videoRef.current.muted = val === 0;
    }
    setIsMuted(val === 0);
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    if (isMuted) {
      videoRef.current.muted = false;
      videoRef.current.volume = volume || 0.5;
      setIsMuted(false);
    } else {
      videoRef.current.muted = true;
      setIsMuted(true);
    }
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type
      const validTypes = ['video/mp4', 'video/webm', 'video/quicktime', 'video/x-m4v'];
      if (!validTypes.includes(file.type) && !file.name.match(/\.(mp4|webm|mov|m4v)$/i)) {
        alert('Please select a valid video file (.mp4, .webm, or .mov)');
        return;
      }

      if (customVideoUrl) {
        URL.revokeObjectURL(customVideoUrl);
      }

      const url = URL.createObjectURL(file);
      setCustomVideoUrl(url);
      setUploadedFileName(file.name);
      setIsPlaying(false);
      setCurrentTime(0);

      // Reset file input so same file can be re-selected if desired
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleResetToDefault = () => {
    if (customVideoUrl) {
      URL.revokeObjectURL(customVideoUrl);
    }
    setCustomVideoUrl(null);
    setUploadedFileName(null);
    setIsPlaying(false);
    setCurrentTime(0);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  useEffect(() => {
    return () => {
      if (customVideoUrl) {
        URL.revokeObjectURL(customVideoUrl);
      }
    };
  }, [customVideoUrl]);

  return (
    <section className="py-24 sm:py-32 bg-[#120E0C] relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-14">
          <div className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-[#C89B66] font-medium mb-3">
            <Film className="w-3.5 h-3.5" />
            <span>Cinematic Atmosphere</span>
          </div>
          <h2 className="text-4xl sm:text-5xl font-serif text-[#FAF5EF] tracking-tight leading-tight mb-4">
            Experience AURA
          </h2>
          <p className="text-base text-[#B5A496] font-light">
            Watch our baristas in motion, listen to the whisper of steamed milk, and immerse yourself in the warm cadence of our café.
          </p>

          {/* Video Upload Control Bar */}
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept="video/mp4,video/webm,video/quicktime,.mp4,.webm,.mov"
              className="hidden"
              id="cafe-video-upload"
            />
            <label
              htmlFor="cafe-video-upload"
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#251B16] hover:bg-[#34251E] border border-[#C89B66]/60 hover:border-[#C89B66] rounded-md text-xs font-semibold uppercase tracking-wider text-[#FAF5EF] cursor-pointer shadow-md transition-all active:scale-[0.98]"
            >
              <Upload className="w-4 h-4 text-[#C89B66]" />
              <span>Upload Your Café Video</span>
            </label>

            {customVideoUrl && (
              <button
                type="button"
                onClick={handleResetToDefault}
                className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#1C1512] hover:bg-[#251B16] border border-[#3A2A22] rounded-md text-xs text-[#C5B5A6] hover:text-white transition-colors cursor-pointer"
                title="Return to Aura signature reel"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Reset to Ambience Reel</span>
              </button>
            )}

            <span className="text-[11px] text-[#7A695E] self-center">
              Supports MP4, WebM, MOV
            </span>
          </div>

          {uploadedFileName && (
            <div className="mt-2 text-xs text-[#C89B66] font-medium">
              ✓ Loaded: {uploadedFileName}
            </div>
          )}
        </div>

        {/* Video Player Container */}
        <div
          ref={containerRef}
          className="relative rounded-2xl overflow-hidden border border-[#3C2C24] shadow-2xl bg-black aspect-video max-w-5xl mx-auto group"
        >
          {/* HTML5 Video Element */}
          <video
            ref={videoRef}
            src={activeVideoSrc}
            poster={heroBg}
            onTimeUpdate={handleTimeUpdate}
            onEnded={() => setIsPlaying(false)}
            onClick={togglePlay}
            playsInline
            loop
            className="w-full h-full object-cover cursor-pointer"
          />

          {/* Big Center Play Button Overlay (when paused) */}
          {!isPlaying && (
            <div
              onClick={togglePlay}
              className="absolute inset-0 flex items-center justify-center bg-black/40 backdrop-blur-[2px] cursor-pointer transition-all"
            >
              <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-[#C89B66]/90 hover:bg-[#D7A873] text-[#120E0C] flex items-center justify-center shadow-2xl transition-transform transform group-hover:scale-110 active:scale-95 pl-1">
                <Play className="w-8 h-8 sm:w-10 sm:h-10 fill-current" />
              </div>
            </div>
          )}

          {/* Custom Overlay Controls (Visible on hover or when paused) */}
          <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-6 bg-gradient-to-t from-black/90 via-black/50 to-transparent transition-opacity duration-300 opacity-90 sm:opacity-0 sm:group-hover:opacity-100 flex flex-col gap-2 z-30">
            {/* Progress Bar */}
            <input
              type="range"
              min="0"
              max={duration || 100}
              step="0.1"
              value={currentTime}
              onChange={handleSeek}
              className="w-full h-1.5 bg-[#423128] accent-[#C89B66] rounded-lg appearance-none cursor-pointer"
              aria-label="Video seek slider"
            />

            <div className="flex items-center justify-between text-xs text-[#EADBCC]">
              {/* Left: Play/Pause, Volume, Time */}
              <div className="flex items-center gap-4">
                <button
                  type="button"
                  onClick={togglePlay}
                  className="p-1.5 hover:text-[#C89B66] transition-colors"
                  aria-label={isPlaying ? 'Pause video' : 'Play video'}
                >
                  {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 fill-current" />}
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={toggleMute}
                    className="p-1 hover:text-[#C89B66] transition-colors"
                    aria-label={isMuted ? 'Unmute' : 'Mute'}
                  >
                    {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                  </button>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={isMuted ? 0 : volume}
                    onChange={handleVolumeChange}
                    className="w-16 sm:w-20 h-1 bg-[#423128] accent-[#C89B66] rounded-lg appearance-none cursor-pointer hidden sm:block"
                    aria-label="Volume slider"
                  />
                </div>

                <span className="tabular-nums font-mono text-[11px] text-[#A89688]">
                  {formatTime(currentTime)} / {formatTime(duration)}
                </span>
              </div>

              {/* Right: Badge & Fullscreen */}
              <div className="flex items-center gap-3">
                <span className="text-[11px] uppercase tracking-wider text-[#C89B66] hidden md:inline">
                  {customVideoUrl ? 'Custom Video Preview' : 'Aura Ambience 4K'}
                </span>
                <button
                  type="button"
                  onClick={toggleFullscreen}
                  className="p-1.5 hover:text-[#C89B66] transition-colors"
                  aria-label="Toggle fullscreen"
                >
                  <Maximize className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
