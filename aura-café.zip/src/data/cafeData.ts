import { MenuItem, ReviewItem, GalleryItem } from '../types/cafe';

import heroInteriorImg from '../assets/images/hero_cafe_interior_1790920421286.jpg';
import aboutArtisanImg from '../assets/images/about_cafe_artisan_1790920440454.jpg';
import signatureLatteImg from '../assets/images/signature_caramel_latte_1790920452310.jpg';
import pastriesDessertsImg from '../assets/images/pastries_croissants_desserts_1790920464312.jpg';
import cozyAtmosphereImg from '../assets/images/cozy_cafe_atmosphere_1790920475942.jpg';

export const ASSETS = {
  hero: heroInteriorImg,
  about: aboutArtisanImg,
  signature: signatureLatteImg,
  pastries: pastriesDessertsImg,
  atmosphere: cozyAtmosphereImg,
};

export const MENU_ITEMS: MenuItem[] = [
  // Coffee
  {
    id: 'espresso',
    name: 'Espresso',
    category: 'Coffee',
    price: 4.00,
    description: 'Double shot of our single-origin Ethiopian roast with thick golden crema and dark cocoa notes.',
    image: signatureLatteImg,
    popular: true,
    calories: '5 kcal',
    dietary: ['Vegan', 'Gluten-Free']
  },
  {
    id: 'cappuccino',
    name: 'Cappuccino',
    category: 'Coffee',
    price: 5.50,
    description: 'Equal parts rich espresso, steamed organic milk, and microfoam dusted with valrhona cocoa powder.',
    image: signatureLatteImg,
    calories: '120 kcal',
    dietary: ['Vegetarian']
  },
  {
    id: 'caramel-latte',
    name: 'Caramel Latte',
    category: 'Coffee',
    price: 6.00,
    description: 'Slow-extracted espresso, steamed velvety milk, and our house-simmered Madagascar vanilla caramel.',
    image: signatureLatteImg,
    popular: true,
    calories: '210 kcal',
    dietary: ['Vegetarian']
  },
  {
    id: 'spanish-latte',
    name: 'Spanish Latte',
    category: 'Coffee',
    price: 6.50,
    description: 'Rich espresso poured over sweet condensed milk, silky microfoam, and a dash of Ceylon cinnamon.',
    image: signatureLatteImg,
    calories: '240 kcal',
    dietary: ['Vegetarian']
  },
  {
    id: 'iced-mocha',
    name: 'Iced Mocha',
    category: 'Coffee',
    price: 6.00,
    description: '70% dark Belgian chocolate melted with hot espresso, shaken with cold whole milk over crystal ice cubes.',
    image: signatureLatteImg,
    calories: '260 kcal',
    dietary: ['Vegetarian']
  },

  // Breakfast
  {
    id: 'croissant',
    name: 'Artisan Croissant',
    category: 'Breakfast',
    price: 4.50,
    description: 'Flaky 27-layer French butter pastry baked fresh every dawn in our stone hearth oven.',
    image: pastriesDessertsImg,
    popular: true,
    calories: '280 kcal',
    dietary: ['Vegetarian']
  },
  {
    id: 'avocado-tartine',
    name: 'Avocado Sourdough Tartine',
    category: 'Breakfast',
    price: 11.50,
    description: 'Crushed Hass avocado, heirloom cherry tomatoes, dukkah crunch, microgreens, and cold-pressed olive oil.',
    image: pastriesDessertsImg,
    calories: '340 kcal',
    dietary: ['Vegan']
  },
  {
    id: 'pain-au-chocolat',
    name: 'Pain au Chocolat',
    category: 'Breakfast',
    price: 5.25,
    description: 'Buttery viennoiserie pastry folded with double batons of dark French baking chocolate.',
    image: pastriesDessertsImg,
    calories: '310 kcal',
    dietary: ['Vegetarian']
  },

  // Desserts
  {
    id: 'tiramisu',
    name: 'Classic Tiramisu',
    category: 'Desserts',
    price: 7.50,
    description: 'Espresso-soaked savoiardi ladyfingers layered with whipped mascarpone cream and Dutch cocoa dusting.',
    image: pastriesDessertsImg,
    popular: true,
    calories: '380 kcal',
    dietary: ['Vegetarian']
  },
  {
    id: 'creme-brulee',
    name: 'Vanilla Bean Crème Brûlée',
    category: 'Desserts',
    price: 8.00,
    description: 'Silky egg custard infused with Tahitian vanilla bean, topped with hand-torched caramelized sugar glass.',
    image: pastriesDessertsImg,
    calories: '320 kcal',
    dietary: ['Gluten-Free', 'Vegetarian']
  },

  // Cakes
  {
    id: 'chocolate-cake',
    name: 'Velvet Chocolate Cake',
    category: 'Cakes',
    price: 7.00,
    description: 'Decadent multi-layered dark cocoa sponge layered with whipped ganache and edible gold leaf flake.',
    image: pastriesDessertsImg,
    popular: true,
    calories: '420 kcal',
    dietary: ['Vegetarian']
  },
  {
    id: 'blueberry-cheesecake',
    name: 'Blueberry Cheesecake',
    category: 'Cakes',
    price: 7.50,
    description: 'New York style baked cream cheese on a graham butter crust, smothered with wild Maine blueberry compote.',
    image: pastriesDessertsImg,
    calories: '410 kcal',
    dietary: ['Vegetarian']
  },

  // Cold Drinks
  {
    id: 'cold-brew-tonic',
    name: 'Cold Brew Tonic',
    category: 'Cold Drinks',
    price: 5.50,
    description: '18-hour cold steeped single-origin espresso charged with botanical elderflower tonic and dehydrated blood orange.',
    image: signatureLatteImg,
    popular: true,
    calories: '45 kcal',
    dietary: ['Vegan', 'Gluten-Free']
  },
  {
    id: 'matcha-iced-latte',
    name: 'Kyoto Ceremonial Iced Matcha',
    category: 'Cold Drinks',
    price: 6.50,
    description: 'Stone-ground Uji ceremonial grade green tea whisked fresh, poured over oat milk and wildflower honey.',
    image: signatureLatteImg,
    calories: '110 kcal',
    dietary: ['Vegetarian']
  },
  {
    id: 'hibiscus-berry-spritz',
    name: 'Sparkling Hibiscus Spritz',
    category: 'Cold Drinks',
    price: 5.25,
    description: 'House-infused Egyptian hibiscus flowers, fresh mint, crushed raspberries, and sparkling mineral water.',
    image: signatureLatteImg,
    calories: '65 kcal',
    dietary: ['Vegan', 'Gluten-Free']
  }
];

export const REVIEWS: ReviewItem[] = [
  {
    id: '1',
    name: 'Elena Rostova',
    role: 'Architect & Regular Guest',
    rating: 5,
    comment: 'AURA CAFÉ has the perfect atmosphere for a slow morning and amazing coffee. The ambient light and walnut textures make working here an absolute joy.',
    date: '2 days ago',
  },
  {
    id: '2',
    name: 'Marcus Vance',
    role: 'Culinary Journalist',
    rating: 5,
    comment: 'Beautiful interior, delicious desserts and genuinely wonderful service. The stone hearth pastries rival Paris, and the roasts are masterfully balanced.',
    date: '1 week ago',
  },
  {
    id: '3',
    name: 'Sophia Chen',
    role: 'Creative Director',
    rating: 5,
    comment: 'The caramel latte is absolutely unforgettable. Not overly sweet, velvety texture, and the warmth of the team makes you feel like an honored guest.',
    date: '3 weeks ago',
  },
  {
    id: '4',
    name: 'Julian Montgomery',
    role: 'Coffee Sommelier',
    rating: 5,
    comment: 'Their single-origin pour overs and cold brew extraction demonstrate true craft precision. A masterclass in luxury specialty coffee hospitality.',
    date: '1 month ago',
  }
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'g1',
    title: 'The Golden Hour Espresso Bar',
    category: 'Interior',
    image: heroInteriorImg,
    aspect: 'wide',
    caption: 'Warm ambient pendant lights casting amber hues across hand-carved dark walnut and brushed brass counters.'
  },
  {
    id: 'g2',
    title: 'Artisan Microfoam Pour',
    category: 'Coffee',
    image: aboutArtisanImg,
    aspect: 'tall',
    caption: 'Master barista handcrafting delicate rosetta latte art with silky whole milk heated to exactly 65°C.'
  },
  {
    id: 'g3',
    title: 'House-Made Caramel Latte',
    category: 'Coffee',
    image: signatureLatteImg,
    aspect: 'square',
    caption: 'Our signature espresso creation with slow-simmered caramel sauce and golden roasted bean notes.'
  },
  {
    id: 'g4',
    title: 'Morning Hearth Bake',
    category: 'Desserts',
    image: pastriesDessertsImg,
    aspect: 'tall',
    caption: 'Crisp golden layered croissants and blueberry tartlets freshly finished with confectioner’s sugar.'
  },
  {
    id: 'g5',
    title: 'The Reading Lounge Corner',
    category: 'Atmosphere',
    image: cozyAtmosphereImg,
    aspect: 'wide',
    caption: 'Sunlit velvet banquettes, curated literature, and tranquil morning stillness in our library nook.'
  },
  {
    id: 'g6',
    title: 'Moments of Connection',
    category: 'People',
    image: aboutArtisanImg,
    aspect: 'square',
    caption: 'Friendly conversations, shared stories, and warm laughter echoing over artisan cups.'
  }
];

export const EXPERIENCE_FEATURES = [
  {
    icon: '☕',
    title: 'Handcrafted Coffee',
    subtitle: 'Micro-Lot Precision',
    description: 'Ethically sourced single-origin Arabica beans roasted locally in small batches to preserve nuanced terroir and aromatic floral oils.'
  },
  {
    icon: '🥐',
    title: 'Fresh Every Morning',
    subtitle: 'Artisan Boulangerie',
    description: 'Laminated by hand with cultured French butter and baked at sunrise to achieve an airy honeycomb interior and crisp flaky crust.'
  },
  {
    icon: '🌿',
    title: 'Cozy Atmosphere',
    subtitle: 'Sanctuary of Calm',
    description: 'Natural oak surfaces, acoustic warmth, gentle golden ambient lighting, and bespoke seating designed for unhurried contemplation.'
  },
  {
    icon: '❤️',
    title: 'Made With Love',
    subtitle: 'Heartfelt Hospitality',
    description: 'Every cup is served with genuine warmth and care, transforming a simple daily beverage into a memorable, restorative ritual.'
  }
];

export const INSTAGRAM_POSTS = [
  {
    id: 'ig1',
    image: signatureLatteImg,
    likes: 1248,
    comments: 42,
    caption: 'Morning golden light hitting our Signature Caramel Latte just right. ☕✨ #AuraCafe #CraftCoffee'
  },
  {
    id: 'ig2',
    image: pastriesDessertsImg,
    likes: 982,
    comments: 31,
    caption: '27 flaky layers of buttery perfection. What’s your morning pastry ritual? 🥐 #AuraBakery'
  },
  {
    id: 'ig3',
    image: heroInteriorImg,
    likes: 2154,
    comments: 87,
    caption: 'Your sanctuary in the heart of the city. Doors open until 10 PM. 🌿 #AuraMoments #CafeDesign'
  },
  {
    id: 'ig4',
    image: aboutArtisanImg,
    likes: 1403,
    comments: 55,
    caption: 'Barista Elena dialing in the Ethiopian Yirgacheffe pour-overs today. #SpecialtyCoffee'
  },
  {
    id: 'ig5',
    image: cozyAtmosphereImg,
    likes: 1876,
    comments: 63,
    caption: 'A good book, a hot cup, and nowhere else you need to be. 📖☕ #SlowLiving'
  },
  {
    id: 'ig6',
    image: pastriesDessertsImg,
    likes: 1120,
    comments: 39,
    caption: 'Afternoon delight: Hand-layered Belgian chocolate cake paired with espresso. 🍫 #AuraDesserts'
  }
];
