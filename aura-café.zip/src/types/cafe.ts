export type MenuCategory = 'All' | 'Coffee' | 'Breakfast' | 'Desserts' | 'Cakes' | 'Cold Drinks';

export interface MenuItem {
  id: string;
  name: string;
  category: 'Coffee' | 'Breakfast' | 'Desserts' | 'Cakes' | 'Cold Drinks';
  price: number;
  description: string;
  image: string;
  popular?: boolean;
  calories?: string;
  dietary?: string[];
}

export interface CartItem {
  id: string;
  item: MenuItem;
  quantity: number;
  selectedOption?: string;
}

export interface ReservationData {
  fullName: string;
  email: string;
  phone: string;
  date: string;
  time: string;
  guests: number;
  seatingArea?: string;
  specialRequest?: string;
}

export interface ReviewItem {
  id: string;
  name: string;
  role: string;
  rating: number;
  comment: string;
  date: string;
  avatar?: string;
}

export type GalleryCategory = 'All' | 'Coffee' | 'Interior' | 'Desserts' | 'People' | 'Atmosphere';

export interface GalleryItem {
  id: string;
  title: string;
  category: 'Coffee' | 'Interior' | 'Desserts' | 'People' | 'Atmosphere';
  image: string;
  aspect: 'tall' | 'wide' | 'square';
  caption: string;
}
