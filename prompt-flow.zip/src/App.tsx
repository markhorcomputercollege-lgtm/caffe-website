import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { FeaturedVideos } from './components/FeaturedVideos';
import { QuoteBanner } from './components/QuoteBanner';
import { LatestTutorials } from './components/LatestTutorials';
import { Footer } from './components/Footer';
import { VideoModal } from './components/VideoModal';
import { SearchModal } from './components/SearchModal';
import { StartLearningModal } from './components/StartLearningModal';
import { YogaTutorial } from './types';

export default function App() {
  const [darkMode, setDarkMode] = useState(false);
  const [currentSection, setCurrentSection] = useState('home');
  const [selectedTutorial, setSelectedTutorial] = useState<YogaTutorial | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [learningModalOpen, setLearningModalOpen] = useState(false);

  // Sync dark mode class on document element
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const handleToggleTheme = () => {
    setDarkMode((prev) => !prev);
  };

  const handleNavigate = (sectionId: string) => {
    setCurrentSection(sectionId);
    if (sectionId === 'home') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <div
      className={`min-h-screen flex flex-col font-sans transition-colors duration-300 ${
        darkMode ? 'dark bg-[#161D19] text-[#E8EFEA]' : 'bg-[#FAF7F2] text-[#2C302E]'
      }`}
    >
      {/* Header with Navigation and Social Icons */}
      <Header
        darkMode={darkMode}
        onToggleTheme={handleToggleTheme}
        onOpenSearch={() => setSearchOpen(true)}
        onNavigate={handleNavigate}
        currentSection={currentSection}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* Hero Section */}
        <Hero
          darkMode={darkMode}
          onToggleTheme={handleToggleTheme}
          onStartLearning={() => setLearningModalOpen(true)}
        />

        {/* Featured Yoga Videos Carousel Section */}
        <FeaturedVideos
          onSelectTutorial={(tut) => setSelectedTutorial(tut)}
          onViewAll={() => handleNavigate('tutorials')}
        />

        {/* Full-width Testimonial Quote Banner */}
        <QuoteBanner />

        {/* Latest Yoga Tutorials Grid */}
        <LatestTutorials onSelectTutorial={(tut) => setSelectedTutorial(tut)} />
      </main>

      {/* Footer */}
      <Footer onNavigate={handleNavigate} />

      {/* Modals & Interactive Overlays */}
      <VideoModal
        tutorial={selectedTutorial}
        onClose={() => setSelectedTutorial(null)}
      />

      <SearchModal
        isOpen={searchOpen}
        onClose={() => setSearchOpen(false)}
        onSelectTutorial={(tut) => setSelectedTutorial(tut)}
      />

      <StartLearningModal
        isOpen={learningModalOpen}
        onClose={() => setLearningModalOpen(false)}
        onSelectTutorial={(tut) => setSelectedTutorial(tut)}
      />
    </div>
  );
}
