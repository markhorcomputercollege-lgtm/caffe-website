import React, { useState } from 'react';
import { Facebook, Twitter, Instagram, Send, Heart, CheckCircle2 } from 'lucide-react';

interface FooterProps {
  onNavigate: (section: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setSubscribed(true);
      setEmail('');
    }
  };

  const instaPhotos = [
    'https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=300&q=80',
    'https://images.unsplash.com/photo-1575052814086-f385e2e2ad1b?auto=format&fit=crop&w=300&q=80',
    'https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&w=300&q=80',
    'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?auto=format&fit=crop&w=300&q=80',
    'https://images.unsplash.com/photo-1588286840104-8957b019727f?auto=format&fit=crop&w=300&q=80',
    'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=300&q=80'
  ];

  return (
    <footer className="w-full bg-[#EDE6DA] dark:bg-[#141A17] text-[#2C302E] dark:text-[#E8EFEA] border-t border-[#DECFC0] dark:border-[#25302A] pt-14 pb-8 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Instagram Preview Row */}
        <div className="mb-12">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-xs font-bold uppercase tracking-[0.2em] text-[#718076] dark:text-[#8FA095]">
              Follow @HashtagYogaStudio
            </h4>
            <span className="text-xs text-[#285A48] dark:text-[#52B788] font-medium hover:underline cursor-pointer">
              Join 45k Practitioners
            </span>
          </div>
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 sm:gap-3">
            {instaPhotos.map((src, i) => (
              <div
                key={i}
                className="group relative aspect-square overflow-hidden rounded-lg bg-neutral-200 dark:bg-neutral-800"
              >
                <img
                  src={src}
                  alt={`Yoga moment ${i + 1}`}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                  <Instagram className="w-5 h-5" />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 4 Column Layout */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 lg:gap-12 pb-12 border-b border-black/10 dark:border-white/10">
          
          {/* Col 1: Brand & Bio (4 cols) */}
          <div className="md:col-span-4 space-y-4">
            <div className="flex flex-col items-start cursor-pointer" onClick={() => onNavigate('home')}>
              <span className="font-serif-heading text-3xl font-semibold tracking-tight text-[#222825] dark:text-[#F3F7F4]">
                #Hashtag
              </span>
              <span className="text-[9px] tracking-[0.3em] font-semibold text-[#285A48] dark:text-[#52B788] uppercase -mt-1">
                My YogaStudio
              </span>
            </div>
            <p className="text-xs sm:text-sm text-[#5C6660] dark:text-[#A3B2A8] leading-relaxed max-w-sm">
              Dedicated to sharing free, accessible yoga tutorials, mindful breathing techniques, and restorative home practice sequences for everyday life.
            </p>
            <div className="flex items-center space-x-3 text-[#285A48] dark:text-[#52B788] pt-1">
              <a href="#facebook" className="p-2 rounded-full bg-black/5 dark:bg-white/5 hover:bg-[#285A48] hover:text-white transition-colors" aria-label="Facebook">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="#twitter" className="p-2 rounded-full bg-black/5 dark:bg-white/5 hover:bg-[#285A48] hover:text-white transition-colors" aria-label="Twitter">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="#instagram" className="p-2 rounded-full bg-black/5 dark:bg-white/5 hover:bg-[#285A48] hover:text-white transition-colors" aria-label="Instagram">
                <Instagram className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Col 2: Navigation Links (2 cols) */}
          <div className="md:col-span-2 space-y-3">
            <h5 className="font-serif-heading text-lg font-bold text-[#1E2522] dark:text-[#F2F6F3]">
              Navigation
            </h5>
            <ul className="space-y-2 text-xs text-[#5C6660] dark:text-[#A3B2A8]">
              <li>
                <button onClick={() => onNavigate('home')} className="hover:text-[#285A48] dark:hover:text-[#52B788] transition-colors">
                  Home
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('featured')} className="hover:text-[#285A48] dark:hover:text-[#52B788] transition-colors">
                  Featured Videos
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('tutorials')} className="hover:text-[#285A48] dark:hover:text-[#52B788] transition-colors">
                  Latest Tutorials
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('testimonials')} className="hover:text-[#285A48] dark:hover:text-[#52B788] transition-colors">
                  Testimonials
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Topics (2 cols) */}
          <div className="md:col-span-2 space-y-3">
            <h5 className="font-serif-heading text-lg font-bold text-[#1E2522] dark:text-[#F2F6F3]">
              Categories
            </h5>
            <ul className="space-y-2 text-xs text-[#5C6660] dark:text-[#A3B2A8]">
              <li>
                <button onClick={() => onNavigate('tutorials')} className="hover:text-[#285A48] dark:hover:text-[#52B788] transition-colors">
                  Health & Alignment
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('tutorials')} className="hover:text-[#285A48] dark:hover:text-[#52B788] transition-colors">
                  Home Studio Setup
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('tutorials')} className="hover:text-[#285A48] dark:hover:text-[#52B788] transition-colors">
                  Morning Meditation
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('tutorials')} className="hover:text-[#285A48] dark:hover:text-[#52B788] transition-colors">
                  Pain Relief & Recovery
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Newsletter Signup (4 cols) */}
          <div className="md:col-span-4 space-y-3">
            <h5 className="font-serif-heading text-lg font-bold text-[#1E2522] dark:text-[#F2F6F3]">
              Daily Asana & Workout Tips
            </h5>
            <p className="text-xs text-[#5C6660] dark:text-[#A3B2A8] leading-relaxed">
              Receive free weekly yoga guides, breathing exercises, and video workout sequences straight to your inbox.
            </p>

            {subscribed ? (
              <div className="flex items-center space-x-2 text-xs font-semibold text-[#285A48] dark:text-[#52B788] bg-[#285A48]/10 p-3 rounded-xl border border-[#285A48]/30">
                <CheckCircle2 className="w-4 h-4" />
                <span>Namaste! You're subscribed to free tutorials.</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex items-center space-x-2">
                <input
                  id="newsletter-email-input"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email address..."
                  className="flex-1 px-3.5 py-2.5 rounded-xl text-xs bg-white dark:bg-[#1F2723] border border-black/10 dark:border-white/10 placeholder:text-[#88958E] text-[#1F2522] dark:text-[#E8EFEA] focus:outline-hidden focus:border-[#285A48]"
                />
                <button
                  type="submit"
                  className="px-4 py-2.5 rounded-xl bg-[#285A48] hover:bg-[#1E4537] text-white text-xs font-semibold tracking-wide transition-colors flex items-center space-x-1.5 shadow-sm"
                >
                  <span>Join</span>
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            )}
          </div>

        </div>

        {/* Bottom Copyright */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-[#738278] dark:text-[#88988E] gap-3">
          <p>© {new Date().getFullYear()} #Hashtag My YogaStudio. All rights reserved.</p>
          <div className="flex items-center space-x-1">
            <span>Crafted with mindfulness</span>
            <Heart className="w-3.5 h-3.5 text-[#C65D3B] fill-current mx-1" />
            <span>for peaceful home practice</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
