import React, { useState } from 'react';
import {
  Facebook,
  Twitter,
  Instagram,
  Search,
  Menu,
  X,
  Sun,
  Moon,
  ChevronDown
} from 'lucide-react';

interface HeaderProps {
  darkMode: boolean;
  onToggleTheme: () => void;
  onOpenSearch: () => void;
  onNavigate: (sectionId: string) => void;
  currentSection: string;
}

export const Header: React.FC<HeaderProps> = ({
  darkMode,
  onToggleTheme,
  onOpenSearch,
  onNavigate,
  currentSection
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  const navItems = [
    {
      id: 'home',
      label: 'HOME',
      hasDropdown: true,
      subItems: [
        { label: 'Classic Home', id: 'home' },
        { label: 'Featured Videos', id: 'featured' },
        { label: 'Latest Tutorials', id: 'tutorials' }
      ]
    },
    {
      id: 'pages',
      label: 'PAGES',
      hasDropdown: true,
      subItems: [
        { label: 'Yoga Courses & Classes', id: 'tutorials' },
        { label: 'Instructor Profiles', id: 'testimonials' },
        { label: 'Studio Equipment & Mats', id: 'featured' }
      ]
    },
    {
      id: 'posts',
      label: 'POSTS FORMAT',
      hasDropdown: true,
      subItems: [
        { label: 'Video Tutorials', id: 'featured' },
        { label: 'Lifestyle & Wellness', id: 'tutorials' },
        { label: 'Meditation & Breathwork', id: 'tutorials' }
      ]
    },
    { id: 'about', label: 'ABOUT', hasDropdown: false },
    { id: 'contact', label: 'CONTACT', hasDropdown: false }
  ];

  return (
    <header className={`w-full transition-colors duration-300 ${darkMode ? 'bg-[#181E1B] text-[#E8EFEA] border-b border-[#2A3430]' : 'bg-[#FAF7F2] text-[#2C302E] border-b border-[#EAE3D6]'}`}>
      {/* Top Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4 pb-3 flex items-center justify-between">
        {/* Social Icons (Left) */}
        <div className="flex items-center space-x-3 text-sm opacity-80">
          <a
            id="social-facebook"
            href="#facebook"
            className="p-1.5 rounded-full hover:text-[#285A48] hover:scale-110 transition-transform"
            aria-label="Facebook"
          >
            <Facebook className="w-4 h-4" />
          </a>
          <a
            id="social-twitter"
            href="#twitter"
            className="p-1.5 rounded-full hover:text-[#285A48] hover:scale-110 transition-transform"
            aria-label="Twitter"
          >
            <Twitter className="w-4 h-4" />
          </a>
          <a
            id="social-instagram"
            href="#instagram"
            className="p-1.5 rounded-full hover:text-[#285A48] hover:scale-110 transition-transform"
            aria-label="Instagram"
          >
            <Instagram className="w-4 h-4" />
          </a>
          <a
            id="social-pinterest"
            href="#pinterest"
            className="p-1.5 rounded-full hover:text-[#285A48] hover:scale-110 transition-transform font-serif font-bold text-xs"
            aria-label="Pinterest"
          >
            P
          </a>
        </div>

        {/* Center Logo */}
        <div
          id="brand-logo"
          onClick={() => onNavigate('home')}
          className="cursor-pointer flex flex-col items-center select-none group"
        >
          <div className="flex items-baseline space-x-1">
            <span className="font-serif-heading text-3xl sm:text-4xl font-semibold tracking-tight text-[#222825] dark:text-[#F3F7F4] group-hover:opacity-90 transition-opacity">
              #Hashtag
            </span>
          </div>
          <span className="text-[9px] sm:text-[10px] tracking-[0.3em] font-semibold text-[#285A48] uppercase -mt-1">
            My YogaStudio
          </span>
        </div>

        {/* Right Controls */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          <button
            id="search-btn"
            onClick={onOpenSearch}
            className="p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-colors"
            aria-label="Search tutorials"
            title="Search yoga workouts"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Desktop & Mobile hamburger menu matching reference */}
          <button
            id="main-drawer-menu-btn"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-colors"
            aria-label="Toggle menu drawer"
            title="Menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          {/* Theme switch button */}
          <button
            id="theme-toggle-btn"
            onClick={onToggleTheme}
            className={`p-2 rounded-full transition-all duration-300 ${
              darkMode ? 'bg-amber-400/10 text-amber-300 hover:bg-amber-400/20' : 'bg-[#285A48]/10 text-[#285A48] hover:bg-[#285A48]/20'
            }`}
            aria-label="Toggle theme"
            title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          >
            {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Floating dot indicator on the right edge matching screenshot */}
      <div className="hidden lg:flex justify-end max-w-7xl mx-auto px-8 -mt-2 -mb-2">
        <span className="w-2 h-2 rounded-full bg-[#1F2421] dark:bg-[#52B788] opacity-80" />
      </div>

      {/* Main Navigation Bar (Desktop) */}
      <nav className="hidden lg:block border-t border-black/5 dark:border-white/5 py-2.5">
        <div className="max-w-7xl mx-auto px-4 flex justify-center items-center space-x-9 text-[13px] font-semibold tracking-wider">
          {navItems.map((item) => (
            <div
              key={item.id}
              className="relative"
              onMouseEnter={() => item.hasDropdown && setActiveDropdown(item.id)}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              <button
                id={`nav-link-${item.id}`}
                onClick={() => onNavigate(item.id)}
                className={`flex items-center space-x-1 py-1 transition-colors uppercase ${
                  currentSection === item.id
                    ? 'text-[#285A48] font-bold border-b-2 border-[#285A48]'
                    : 'text-[#4A524D] dark:text-[#B6C2BA] hover:text-[#285A48] dark:hover:text-[#4ADE80]'
                }`}
              >
                <span>{item.label}</span>
                {item.hasDropdown && <ChevronDown className="w-3.5 h-3.5 opacity-60 ml-0.5" />}
              </button>

              {/* Dropdown Menu */}
              {item.hasDropdown && activeDropdown === item.id && item.subItems && (
                <div className="absolute left-0 top-full mt-1 w-52 bg-white dark:bg-[#202723] rounded-lg shadow-xl border border-black/10 dark:border-white/10 py-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                  {item.subItems.map((sub, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        onNavigate(sub.id);
                        setActiveDropdown(null);
                      }}
                      className="w-full text-left px-4 py-2 text-xs text-neutral-700 dark:text-neutral-200 hover:bg-[#285A48]/10 hover:text-[#285A48] dark:hover:text-[#4ADE80] transition-colors"
                    >
                      {sub.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </nav>

      {/* Navigation Drawer Menu (Mobile & Desktop quick panel) */}
      {mobileMenuOpen && (
        <div className="border-t border-black/10 dark:border-white/10 px-4 sm:px-8 py-5 space-y-4 bg-[#FAF7F2] dark:bg-[#181E1B] shadow-2xl animate-in slide-in-from-top-2 duration-200">
          <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-widest text-[#285A48] dark:text-[#52B788]">
                Quick Navigation
              </h4>
              {navItems.map((item) => (
                <div key={item.id} className="border-b border-black/5 dark:border-white/5 pb-2">
                  <button
                    onClick={() => {
                      onNavigate(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className="w-full flex items-center justify-between text-left text-sm font-semibold tracking-wider py-1 text-[#2C302E] dark:text-[#E8EFEA] hover:text-[#285A48]"
                  >
                    <span>{item.label}</span>
                    {item.hasDropdown && <ChevronDown className="w-4 h-4 opacity-50" />}
                  </button>
                  {item.subItems && (
                    <div className="pl-3 mt-1 space-y-1">
                      {item.subItems.map((sub, idx) => (
                        <button
                          key={idx}
                          onClick={() => {
                            onNavigate(sub.id);
                            setMobileMenuOpen(false);
                          }}
                          className="block text-xs text-[#626C66] dark:text-[#9DAAA1] py-0.5 hover:text-[#285A48]"
                        >
                          • {sub.label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div className="space-y-3 hidden md:block">
              <h4 className="text-xs font-bold uppercase tracking-widest text-[#285A48] dark:text-[#52B788]">
                Studio Highlights
              </h4>
              <p className="text-xs text-[#525B55] dark:text-[#9DAAA1] leading-relaxed">
                Welcome to #Hashtag Yoga Studio. Discover 130+ mindful lessons, beginner to master asana tutorials, breathwork sequences, and home studio styling guides.
              </p>
              <div className="pt-2">
                <button
                  onClick={() => {
                    onNavigate('tutorials');
                    setMobileMenuOpen(false);
                  }}
                  className="px-4 py-2 text-xs font-semibold rounded-full bg-[#285A48] text-white hover:bg-[#1E4336] transition-colors"
                >
                  Explore All Tutorials
                </button>
              </div>
            </div>

            <div className="space-y-3 hidden md:block">
              <h4 className="text-xs font-bold uppercase tracking-widest text-[#285A48] dark:text-[#52B788]">
                Weekly Schedule
              </h4>
              <ul className="text-xs text-[#525B55] dark:text-[#9DAAA1] space-y-1.5">
                <li>• <strong>Mon - Fri:</strong> 6:30 AM Sunrise Vinyasa</li>
                <li>• <strong>Wednesdays:</strong> 5:00 PM Gentle Desk Relief</li>
                <li>• <strong>Weekends:</strong> 9:00 AM Nature & Inversions</li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
