import React, { useState, useEffect } from 'react';
import { MandalaPattern } from './MandalaPattern';
import { Sun, Moon, ArrowRight, Sparkles } from 'lucide-react';
import { HERO_STATS } from '../data/yogaData';

interface HeroProps {
  darkMode: boolean;
  onToggleTheme: () => void;
  onStartLearning: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  darkMode,
  onToggleTheme,
  onStartLearning
}) => {
  const [cursorBlink, setCursorBlink] = useState(true);

  useEffect(() => {
    const interval = setInterval(() => {
      setCursorBlink((prev) => !prev);
    }, 600);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative overflow-hidden pt-6 sm:pt-10 pb-16 lg:pb-24 transition-colors duration-300">
      {/* Floating Theme Switcher on top right as seen in screenshot */}
      <button
        id="hero-theme-toggle-floating"
        onClick={onToggleTheme}
        className="absolute top-4 right-4 sm:top-6 sm:right-8 z-20 w-10 h-10 rounded-full bg-black/5 dark:bg-white/10 hover:bg-black/10 dark:hover:bg-white/20 flex items-center justify-center text-[#285A48] dark:text-amber-300 transition-all duration-300 shadow-sm"
        aria-label="Toggle dark/light mode"
        title={darkMode ? 'Switch to Light' : 'Switch to Dark'}
      >
        {darkMode ? <Sun className="w-5 h-5 animate-spin-slow" /> : <Moon className="w-5 h-5" />}
      </button>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Left Content (5-6 cols) */}
          <div className="lg:col-span-6 z-10 space-y-6 sm:space-y-8">
            {/* Main Headline */}
            <div className="space-y-3">
              <h1 className="font-serif-heading text-4xl sm:text-5xl lg:text-[54px] font-semibold text-[#1F2421] dark:text-[#F3F7F4] leading-[1.15] tracking-tight">
                Best Yoga tutorials for{' '}
                <span className="block mt-1">
                  Home workouts
                  <span
                    className={`inline-block w-[3px] h-[38px] sm:h-[48px] bg-[#285A48] dark:bg-[#52B788] ml-1.5 translate-y-1 ${
                      cursorBlink ? 'opacity-100' : 'opacity-0'
                    }`}
                  />
                </span>
              </h1>

              <p className="text-sm sm:text-base text-[#5A635E] dark:text-[#A7B5AC] max-w-lg leading-relaxed pt-2">
                Finding the best yoga tutorials for home workouts can greatly enhance your practice and help you achieve your fitness.
              </p>
            </div>

            {/* CTA Button */}
            <div className="pt-2">
              <button
                id="start-learning-btn"
                onClick={onStartLearning}
                className="group inline-flex items-center space-x-2.5 px-8 py-3.5 rounded-full bg-[#285A48] hover:bg-[#1E4537] text-white font-medium text-sm tracking-wide shadow-md hover:shadow-lg transition-all transform hover:-translate-y-0.5 active:translate-y-0"
              >
                <span>Start Learning</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>

            {/* Circular Stats Badges as in the reference image */}
            <div className="pt-4 sm:pt-6 flex items-center space-x-4 sm:space-x-6">
              {HERO_STATS.map((stat, idx) => (
                <div
                  key={idx}
                  id={`stat-badge-${idx}`}
                  className="w-20 h-20 sm:w-24 sm:h-24 rounded-full border border-[#D5C7B2]/70 dark:border-[#3E4D45] bg-[#FAF5EC]/80 dark:bg-[#1F2723]/80 flex flex-col items-center justify-center p-2 text-center shadow-sm hover:border-[#285A48] dark:hover:border-[#52B788] transition-colors"
                >
                  <span className="font-serif-heading text-lg sm:text-xl font-bold text-[#A8482A] dark:text-[#E76F51] leading-none">
                    {stat.count}
                  </span>
                  <span className="text-[11px] sm:text-xs text-[#525D56] dark:text-[#A3B2A8] font-medium mt-1">
                    {stat.label}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Right Imagery (6-7 cols) */}
          <div className="lg:col-span-6 relative flex justify-center lg:justify-end items-center mt-6 lg:mt-0">
            {/* Mandala Background Pattern */}
            <div className="absolute inset-0 flex items-center justify-center -translate-y-6 lg:-translate-y-8 pointer-events-none">
              <MandalaPattern
                size={580}
                color={darkMode ? '#8FA396' : '#C5A880'}
                className="animate-spin-very-slow scale-110 sm:scale-125"
              />
            </div>

            {/* Main Yoga Woman Illustration & Photo Composition with Woven Rug & Fringe */}
            <div className="relative z-10 w-full max-w-lg lg:max-w-xl flex flex-col items-center">
              {/* Meditating Yogi with soft organic shadow and seamless floor contact */}
              <div className="relative group w-full flex justify-center">
                <div className="relative z-10 overflow-hidden rounded-t-[140px] rounded-b-2xl max-w-sm sm:max-w-md shadow-2xl border border-black/5 dark:border-white/10 bg-gradient-to-b from-transparent to-black/5">
                  <img
                    src="https://images.unsplash.com/photo-1545205597-3d9d02c29597?auto=format&fit=crop&w=1000&q=85"
                    alt="Yoga instructor meditating in olive activewear in lotus pose"
                    className="w-full h-auto max-h-[460px] object-cover object-center transform group-hover:scale-102 transition-transform duration-700"
                  />
                  
                  {/* Subtle inner gradient shadow to blend toward mat */}
                  <div className="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-black/20 to-transparent pointer-events-none" />
                </div>
              </div>

              {/* Realistic Woven Rug with Fringes under the practitioner matching screenshot */}
              <div className="relative z-20 -mt-3 w-full max-w-md sm:max-w-lg">
                {/* Woven Mat Base */}
                <div className="h-4 sm:h-5 w-full bg-[#EAE0D2] dark:bg-[#2C3730] border-t border-[#D5C7B2] dark:border-[#3E4E45] rounded-xs shadow-md flex items-center justify-between px-3">
                  <div className="w-full h-full bg-repeating-linear-gradient opacity-30" style={{
                    backgroundImage: 'repeating-linear-gradient(90deg, #8B7A68 0px, #8B7A68 2px, transparent 2px, transparent 6px)'
                  }} />
                </div>
                {/* Rug Fringes / Tassels */}
                <div className="w-full flex justify-around px-2 overflow-hidden h-3.5 opacity-80">
                  {Array.from({ length: 42 }).map((_, i) => (
                    <span
                      key={i}
                      className="w-[1.5px] h-full bg-[#D1C3AD] dark:bg-[#435248] rounded-b-full transform origin-top"
                      style={{ height: `${8 + (i % 3) * 2}px` }}
                    />
                  ))}
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
