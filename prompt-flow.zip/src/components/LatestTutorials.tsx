import React, { useState } from 'react';
import { Play, Image as ImageIcon, Sparkles, Filter } from 'lucide-react';
import { LATEST_TUTORIALS } from '../data/yogaData';
import { YogaCategory, YogaTutorial } from '../types';

interface LatestTutorialsProps {
  onSelectTutorial: (tutorial: YogaTutorial) => void;
}

export const LatestTutorials: React.FC<LatestTutorialsProps> = ({
  onSelectTutorial
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories: string[] = [
    'All',
    'Health',
    'Tutorial',
    'Meditation',
    'Lifestyle',
    'Pain Relief'
  ];

  const filteredTutorials =
    selectedCategory === 'All'
      ? LATEST_TUTORIALS
      : LATEST_TUTORIALS.filter((item) => item.category === selectedCategory);

  const getTagColor = (cat: YogaCategory | string) => {
    switch (cat) {
      case 'Health':
        return 'bg-[#C26743] text-white';
      case 'Lifestyle':
        return 'bg-[#285A48] text-white';
      case 'Pain Relief':
        return 'bg-[#C26743] text-white';
      case 'Meditation':
        return 'bg-[#C26743] text-white';
      case 'Tutorial':
        return 'bg-[#D97757] text-white';
      default:
        return 'bg-[#285A48] text-white';
    }
  };

  // Specific media badge colors matching the screenshot
  const getMediaBadge = (item: YogaTutorial, index: number) => {
    // In screenshot:
    // Card 0: Red circular play button
    // Card 1: Green rounded gallery/camera icon
    // Card 2: Red circular play button
    // Card 3: Green circular play button
    // Card 4: Terracotta gallery icon
    // Card 5: Green circular play button
    const isPlay = item.type === 'video';
    const isRedPlay = index === 0 || index === 2;
    const isTerracottaGallery = index === 4;

    if (isPlay) {
      return (
        <div
          className={`w-9 h-9 rounded-full flex items-center justify-center shadow-md ${
            isRedPlay
              ? 'bg-[#C65D3B] text-white hover:bg-[#b04f2f]'
              : 'bg-[#285A48] text-white hover:bg-[#1f483a]'
          } transition-transform group-hover:scale-110`}
        >
          <Play className="w-4 h-4 fill-current ml-0.5" />
        </div>
      );
    } else {
      return (
        <div
          className={`w-9 h-9 rounded-lg flex items-center justify-center shadow-md ${
            isTerracottaGallery ? 'bg-[#C65D3B] text-white' : 'bg-[#285A48] text-white'
          } transition-transform group-hover:scale-110`}
        >
          <ImageIcon className="w-4 h-4" />
        </div>
      );
    }
  };

  return (
    <section id="tutorials" className="py-12 sm:py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Section Title */}
      <div className="text-center mb-10 space-y-3">
        <h2 className="font-serif-heading text-3xl sm:text-4xl lg:text-[42px] font-semibold text-[#A8482A] dark:text-[#E76F51] tracking-tight">
          Latest Yoga Tutorials
        </h2>
        <p className="text-sm text-[#5F6B64] dark:text-[#9FB0A6] max-w-md mx-auto">
          Explore curated asanas, studio setup guides, and mindfulness practices designed for your daily routine.
        </p>

        {/* Category Filters */}
        <div className="flex flex-wrap items-center justify-center gap-2 pt-4">
          <div className="flex items-center text-xs font-semibold text-[#7C8880] dark:text-[#9AA8A0] mr-2">
            <Filter className="w-3.5 h-3.5 mr-1" />
            <span>Filter:</span>
          </div>
          {categories.map((cat) => (
            <button
              key={cat}
              id={`filter-btn-${cat.toLowerCase().replace(/\s+/g, '-')}`}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold tracking-wide transition-all ${
                selectedCategory === cat
                  ? 'bg-[#285A48] text-white shadow-sm'
                  : 'bg-[#EFE7D8]/70 dark:bg-[#202924] text-[#4A554E] dark:text-[#B1C0B6] hover:bg-[#E2D8C5] dark:hover:bg-[#2B3730]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* 2 Rows of 3 Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredTutorials.map((item, index) => (
          <article
            key={item.id}
            id={`tutorial-card-${item.id}`}
            onClick={() => onSelectTutorial(item)}
            className="cursor-pointer group flex flex-col bg-[#FAF5EC]/80 dark:bg-[#1E2622]/80 rounded-xl overflow-hidden border border-[#E8DFC8]/70 dark:border-[#2F3C35] hover:shadow-xl hover:-translate-y-1.5 transition-all duration-300"
          >
            {/* Top Media Image */}
            <div className="relative aspect-[4/3] w-full overflow-hidden bg-neutral-100 dark:bg-neutral-800">
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                loading="lazy"
              />

              {/* Floating Media Icon (Play or Gallery) in top right */}
              <div className="absolute top-4 right-4 z-10">
                {getMediaBadge(item, index)}
              </div>

              {/* Bottom level & duration tag */}
              <div className="absolute bottom-3 left-3 bg-black/60 backdrop-blur-xs px-2.5 py-1 rounded text-[11px] font-medium text-white flex items-center space-x-1.5">
                <Sparkles className="w-3 h-3 text-amber-300" />
                <span>{item.level}</span>
                <span>•</span>
                <span>{item.duration}</span>
              </div>
            </div>

            {/* Card Content */}
            <div className="p-6 flex flex-col items-center text-center flex-1 justify-between">
              {/* Category Pill Tag */}
              <div className="mb-3">
                <span
                  className={`inline-block text-[11px] font-semibold px-3 py-0.5 rounded-full tracking-wider uppercase shadow-xs ${getTagColor(
                    item.category
                  )}`}
                >
                  {item.category}
                </span>
              </div>

              {/* Title */}
              <h3 className="font-serif-heading text-xl sm:text-[22px] font-semibold text-[#212724] dark:text-[#F0F5F2] leading-snug group-hover:text-[#285A48] dark:group-hover:text-[#52B788] transition-colors line-clamp-2 mb-4">
                {item.title}
              </h3>

              {/* Date with horizontal divider lines */}
              <div className="w-full flex items-center justify-center space-x-3 text-[11px] text-[#7C8880] dark:text-[#9AA8A0] font-medium tracking-wider">
                <span className="w-8 h-[1px] bg-[#D7CCBC] dark:bg-[#3D4C44]" />
                <span className="uppercase">{item.date}</span>
                <span className="w-8 h-[1px] bg-[#D7CCBC] dark:bg-[#3D4C44]" />
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
};
