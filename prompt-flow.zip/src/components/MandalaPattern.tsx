import React from 'react';

interface MandalaPatternProps {
  className?: string;
  color?: string;
  size?: number;
}

export const MandalaPattern: React.FC<MandalaPatternProps> = ({
  className = '',
  color = '#C5A880',
  size = 500
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 500 500"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`pointer-events-none select-none opacity-40 ${className}`}
    >
      <circle cx="250" cy="250" r="230" stroke={color} strokeWidth="1" strokeDasharray="3 3" />
      <circle cx="250" cy="250" r="210" stroke={color} strokeWidth="1.2" />
      <circle cx="250" cy="250" r="180" stroke={color} strokeWidth="0.8" />
      <circle cx="250" cy="250" r="140" stroke={color} strokeWidth="1.2" />
      <circle cx="250" cy="250" r="90" stroke={color} strokeWidth="1" />
      <circle cx="250" cy="250" r="45" stroke={color} strokeWidth="1.5" />
      
      {/* Radial Petals 12-fold */}
      {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map((angle, i) => (
        <g key={i} transform={`rotate(${angle} 250 250)`}>
          <path
            d="M 250 110 C 270 145 285 185 250 220 C 215 185 230 145 250 110 Z"
            stroke={color}
            strokeWidth="1"
            fill="none"
          />
          <path
            d="M 250 40 C 280 90 290 140 250 180 C 210 140 220 90 250 40 Z"
            stroke={color}
            strokeWidth="1.2"
            fill="none"
          />
          <circle cx="250" cy="40" r="3" fill={color} />
          <circle cx="250" cy="110" r="2.5" fill={color} />
          <line x1="250" y1="20" x2="250" y2="40" stroke={color} strokeWidth="1" />
        </g>
      ))}

      {/* Radial 24-point accents */}
      {[15, 45, 75, 105, 135, 165, 195, 225, 255, 285, 315, 345].map((angle, i) => (
        <g key={`sub-${i}`} transform={`rotate(${angle} 250 250)`}>
          <path
            d="M 250 70 Q 260 110 250 140 Q 240 110 250 70 Z"
            stroke={color}
            strokeWidth="0.8"
            fill="none"
          />
          <circle cx="250" cy="68" r="2" fill={color} />
        </g>
      ))}
    </svg>
  );
};
