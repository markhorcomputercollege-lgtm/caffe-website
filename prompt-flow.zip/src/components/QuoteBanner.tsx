import React from 'react';
import { MandalaPattern } from './MandalaPattern';
import { TESTIMONIAL_DATA } from '../data/yogaData';

export const QuoteBanner: React.FC = () => {
  return (
    <section id="testimonials" className="relative my-8 sm:my-14 overflow-hidden bg-[#F2ECE1] dark:bg-[#1A221E] border-y border-[#E6DCcb] dark:border-[#2C3831] py-14 sm:py-16 transition-colors duration-300">
      {/* Left Mandala Watermark */}
      <div className="absolute -left-36 top-1/2 -translate-y-1/2 pointer-events-none">
        <MandalaPattern size={480} color="#C4B49C" className="opacity-30 dark:opacity-15" />
      </div>

      {/* Right Mandala Watermark */}
      <div className="absolute -right-36 top-1/2 -translate-y-1/2 pointer-events-none">
        <MandalaPattern size={480} color="#C4B49C" className="opacity-30 dark:opacity-15" />
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          
          {/* Left: Yoga Practitioner Pose Photo */}
          <div className="md:col-span-5 flex justify-center">
            <div className="relative group max-w-xs sm:max-w-sm">
              <div className="overflow-hidden rounded-3xl shadow-lg border border-[#D5C5B0]/60 dark:border-white/10 bg-gradient-to-t from-black/20 via-transparent to-transparent">
                <img
                  src={TESTIMONIAL_DATA.image}
                  alt="Yoga backbend pose"
                  className="w-full h-64 sm:h-76 object-cover object-center group-hover:scale-105 transition-transform duration-700"
                />
              </div>
            </div>
          </div>

          {/* Right: Quote Box */}
          <div className="md:col-span-7 flex flex-col items-center md:items-start text-center md:text-left space-y-4">
            {/* Green Quotation Mark Icon */}
            <div className="text-[#285A48] dark:text-[#52B788] flex space-x-1 select-none">
              <svg className="w-10 h-10 fill-current" viewBox="0 0 24 24">
                <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
              </svg>
            </div>

            {/* Quote Body */}
            <blockquote className="font-serif-heading italic text-xl sm:text-2xl lg:text-[27px] leading-relaxed text-[#232B26] dark:text-[#E8EFEA] max-w-xl">
              {TESTIMONIAL_DATA.quote}
            </blockquote>

            {/* Author Credit with Divider Line */}
            <div className="pt-2 flex items-center space-x-3">
              <span className="w-10 h-[1.5px] bg-[#C27858]" />
              <span className="text-xs sm:text-[13px] font-semibold tracking-[0.2em] text-[#C27858] uppercase">
                {TESTIMONIAL_DATA.author}, {TESTIMONIAL_DATA.location}
              </span>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
