import React, { useState, useMemo } from 'react';
import { Search, X, Play, BookOpen, Sparkles } from 'lucide-react';
import { FEATURED_VIDEOS, LATEST_TUTORIALS } from '../data/yogaData';
import { YogaTutorial } from '../types';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTutorial: (tutorial: YogaTutorial) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onSelectTutorial
}) => {
  const [query, setQuery] = useState('');

  const allItems = useMemo(() => {
    const combined = [...FEATURED_VIDEOS, ...LATEST_TUTORIALS];
    // Remove duplicates by ID
    const map = new Map<string, YogaTutorial>();
    combined.forEach((item) => map.set(item.id, item));
    return Array.from(map.values());
  }, []);

  const filtered = useMemo(() => {
    if (!query.trim()) return allItems.slice(0, 4);
    const q = query.toLowerCase();
    return allItems.filter(
      (item) =>
        item.title.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q) ||
        item.instructor.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q)
    );
  }, [query, allItems]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-150">
      <div
        className="w-full max-w-2xl bg-[#FAF7F2] dark:bg-[#1C2420] rounded-2xl shadow-2xl overflow-hidden border border-black/10 dark:border-white/10 flex flex-col"
        role="dialog"
      >
        {/* Search Input Bar */}
        <div className="p-4 sm:p-5 border-b border-black/10 dark:border-white/10 flex items-center space-x-3">
          <Search className="w-5 h-5 text-[#285A48] dark:text-[#52B788] shrink-0" />
          <input
            id="search-input"
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search yoga asanas, home workouts, breathwork, or instructors..."
            className="w-full bg-transparent text-sm sm:text-base text-[#1E2522] dark:text-[#E8EFEA] placeholder:text-[#88948D] focus:outline-hidden"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="text-xs text-[#88948D] hover:text-[#285A48]"
            >
              Clear
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-black/5 dark:hover:bg-white/10 text-[#67746D]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Suggestions Chips */}
        <div className="px-5 py-2.5 bg-black/[0.02] dark:bg-white/[0.02] border-b border-black/5 dark:border-white/5 flex items-center space-x-2 text-xs overflow-x-auto">
          <span className="text-[#88948D] shrink-0 font-medium">Popular:</span>
          {['Asanas', 'Meditation', 'Beginner', 'Pain Relief', 'Morning Flow'].map((chip) => (
            <button
              key={chip}
              onClick={() => setQuery(chip)}
              className="px-2.5 py-1 rounded-full bg-white dark:bg-[#252F2A] border border-black/5 dark:border-white/10 hover:border-[#285A48] text-[#4A554F] dark:text-[#B3C1B7] shrink-0 transition-colors"
            >
              {chip}
            </button>
          ))}
        </div>

        {/* Results List */}
        <div className="max-h-[60vh] overflow-y-auto p-4 space-y-2">
          {filtered.length === 0 ? (
            <div className="py-12 text-center text-[#88948D] space-y-2">
              <p className="text-sm font-medium">No yoga tutorials found matching "{query}"</p>
              <p className="text-xs">Try searching for "Health", "Meditation", or "Asanas"</p>
            </div>
          ) : (
            filtered.map((item) => (
              <div
                key={item.id}
                onClick={() => {
                  onSelectTutorial(item);
                  onClose();
                }}
                className="group flex items-center justify-between p-3 rounded-xl hover:bg-[#EFE7D8]/60 dark:hover:bg-[#252F2A] cursor-pointer transition-colors border border-transparent hover:border-black/5"
              >
                <div className="flex items-center space-x-3.5">
                  <img
                    src={item.image}
                    alt={item.title}
                    className="w-16 h-12 object-cover rounded-lg shrink-0"
                  />
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-[#C27858]">
                        {item.category}
                      </span>
                      <span className="text-[10px] text-[#88948D]">• {item.level}</span>
                    </div>
                    <h4 className="text-sm font-semibold text-[#1E2522] dark:text-[#F0F5F2] group-hover:text-[#285A48] dark:group-hover:text-[#52B788] transition-colors line-clamp-1">
                      {item.title}
                    </h4>
                    <p className="text-xs text-[#6F7B74] dark:text-[#9AA8A0]">
                      {item.instructor} • {item.duration}
                    </p>
                  </div>
                </div>

                <div className="shrink-0 pl-3">
                  {item.type === 'video' ? (
                    <Play className="w-4 h-4 text-[#285A48] group-hover:scale-110 transition-transform" />
                  ) : (
                    <BookOpen className="w-4 h-4 text-[#C27858] group-hover:scale-110 transition-transform" />
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
