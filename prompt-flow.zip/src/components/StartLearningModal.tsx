import React, { useState } from 'react';
import { X, Sparkles, Compass, Check, ArrowRight, Heart, Zap, ShieldAlert, Moon } from 'lucide-react';
import { LATEST_TUTORIALS } from '../data/yogaData';
import { YogaTutorial } from '../types';

interface StartLearningModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTutorial: (tutorial: YogaTutorial) => void;
}

export const StartLearningModal: React.FC<StartLearningModalProps> = ({
  isOpen,
  onClose,
  onSelectTutorial
}) => {
  const [selectedGoal, setSelectedGoal] = useState('flexibility');
  const [selectedTime, setSelectedTime] = useState('20');
  const [selectedLevel, setSelectedLevel] = useState('Beginner');

  if (!isOpen) return null;

  const goals = [
    {
      id: 'flexibility',
      title: 'Deep Flexibility & Mobility',
      desc: 'Release tight hips, hamstrings & spine',
      icon: Compass
    },
    {
      id: 'stress',
      title: 'Stress Relief & Calm',
      desc: 'Soothe nervous system & clear thoughts',
      icon: Heart
    },
    {
      id: 'energy',
      title: 'Morning Energy & Tone',
      desc: 'Ignite core fire and awaken muscles',
      icon: Zap
    },
    {
      id: 'pain',
      title: 'Back & Neck Pain Relief',
      desc: 'Gentle restorative posture realignment',
      icon: ShieldAlert
    }
  ];

  const handleLaunchPractice = () => {
    // Pick the most suitable tutorial matching user preference
    const matched =
      LATEST_TUTORIALS.find((t) => t.level === selectedLevel) || LATEST_TUTORIALS[0];
    onSelectTutorial(matched);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-2xl bg-[#FAF7F2] dark:bg-[#1A221E] rounded-2xl shadow-2xl overflow-hidden border border-black/10 dark:border-white/10 text-[#2C302E] dark:text-[#E8EFEA] p-6 sm:p-8"
        role="dialog"
      >
        <button
          id="close-learning-modal"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/10 text-[#6C7971]"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center space-y-2 mb-6">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-[#285A48]/10 text-[#285A48] dark:text-[#52B788] text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Personalized Practice Journey</span>
          </div>
          <h3 className="font-serif-heading text-2xl sm:text-3xl font-semibold text-[#1F2522] dark:text-[#F3F7F4]">
            Start Your Home Workout
          </h3>
          <p className="text-xs sm:text-sm text-[#5F6D65] dark:text-[#A3B2A8] max-w-md mx-auto">
            Select your focus for today and let Hashtag Yoga curate the ideal sequence for your body.
          </p>
        </div>

        {/* Step 1: Practice Goal */}
        <div className="space-y-3 mb-6">
          <label className="text-xs font-bold uppercase tracking-wider text-[#6A7870] dark:text-[#9FB0A6]">
            1. Select Your Intention
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {goals.map((g) => {
              const Icon = g.icon;
              const isSelected = selectedGoal === g.id;
              return (
                <button
                  key={g.id}
                  onClick={() => setSelectedGoal(g.id)}
                  className={`p-3 rounded-xl border text-left flex items-start space-x-3 transition-all ${
                    isSelected
                      ? 'border-[#285A48] bg-[#285A48]/10 dark:bg-[#285A48]/20 text-[#1F2522] dark:text-white shadow-sm'
                      : 'border-black/10 dark:border-white/10 hover:border-[#285A48]/50 bg-white/50 dark:bg-white/5'
                  }`}
                >
                  <div
                    className={`p-2 rounded-lg shrink-0 ${
                      isSelected ? 'bg-[#285A48] text-white' : 'bg-black/5 dark:bg-white/10'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold leading-snug">{g.title}</h5>
                    <p className="text-[11px] opacity-75 mt-0.5">{g.desc}</p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Step 2: Time & Level */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-8">
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-[#6A7870] dark:text-[#9FB0A6] block mb-2">
              2. Available Time
            </label>
            <div className="flex space-x-2">
              {['10 min', '20 min', '35 min', '45 min'].map((time) => {
                const num = time.split(' ')[0];
                const isSelected = selectedTime === num;
                return (
                  <button
                    key={time}
                    onClick={() => setSelectedTime(num)}
                    className={`flex-1 py-2 text-xs font-semibold rounded-lg border transition-colors ${
                      isSelected
                        ? 'bg-[#285A48] text-white border-[#285A48]'
                        : 'border-black/10 dark:border-white/10 hover:bg-black/5 dark:hover:bg-white/5'
                    }`}
                  >
                    {time}
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-[#6A7870] dark:text-[#9FB0A6] block mb-2">
              3. Experience Level
            </label>
            <div className="flex space-x-2">
              {['Beginner', 'Intermediate', 'Advanced'].map((lvl) => {
                const isSelected = selectedLevel === lvl;
                return (
                  <button
                    key={lvl}
                    onClick={() => setSelectedLevel(lvl)}
                    className={`flex-1 py-2 text-xs font-semibold rounded-lg border transition-colors ${
                      isSelected
                        ? 'bg-[#285A48] text-white border-[#285A48]'
                        : 'border-black/10 dark:border-white/10 hover:bg-black/5 dark:hover:bg-white/5'
                    }`}
                  >
                    {lvl}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Action Button */}
        <button
          id="confirm-start-practice"
          onClick={handleLaunchPractice}
          className="w-full py-3.5 rounded-full bg-[#285A48] hover:bg-[#1E4537] text-white font-semibold text-sm tracking-wide shadow-lg flex items-center justify-center space-x-2 transition-transform transform active:scale-98"
        >
          <span>Begin Today's {selectedTime}m Practice</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
