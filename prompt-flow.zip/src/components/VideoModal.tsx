import React, { useState, useEffect } from 'react';
import {
  X,
  Play,
  Pause,
  Volume2,
  VolumeX,
  RotateCcw,
  CheckCircle2,
  Share2,
  Bookmark,
  Sparkles,
  Clock,
  User,
  Award
} from 'lucide-react';
import { YogaTutorial } from '../types';

interface VideoModalProps {
  tutorial: YogaTutorial | null;
  onClose: () => void;
}

export const VideoModal: React.FC<VideoModalProps> = ({ tutorial, onClose }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [saved, setSaved] = useState(false);
  const [progressSec, setProgressSec] = useState(0);
  const totalSec = 1200; // 20 minutes mock session

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isPlaying) {
      timer = setInterval(() => {
        setProgressSec((prev) => (prev >= totalSec ? 0 : prev + 1));
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isPlaying]);

  if (!tutorial) return null;

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const percent = Math.min(100, (progressSec / totalSec) * 100);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-4xl max-h-[90vh] bg-[#FAF7F2] dark:bg-[#18201C] rounded-2xl shadow-2xl overflow-hidden flex flex-col border border-black/10 dark:border-white/10 text-[#2C302E] dark:text-[#E8EFEA]"
        role="dialog"
        aria-modal="true"
      >
        {/* Close Button */}
        <button
          id="close-modal-btn"
          onClick={onClose}
          className="absolute top-4 right-4 z-30 p-2 rounded-full bg-black/40 hover:bg-black/70 text-white transition-colors"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Video Player / Media Header */}
        <div className="relative aspect-video w-full bg-neutral-950 overflow-hidden flex items-center justify-center">
          <img
            src={tutorial.image}
            alt={tutorial.title}
            className={`w-full h-full object-cover transition-opacity duration-500 ${
              isPlaying ? 'opacity-85 filter brightness-95' : 'opacity-70'
            }`}
          />

          {/* Breathing ambient ring overlay when playing */}
          {isPlaying && (
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
              <div className="w-48 h-48 rounded-full border border-white/20 animate-ping opacity-25" />
            </div>
          )}

          {/* Central Play/Pause Watermark */}
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="z-20 w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-[#285A48]/90 hover:bg-[#285A48] text-white flex items-center justify-center shadow-2xl transition-transform hover:scale-105 active:scale-95"
            aria-label={isPlaying ? 'Pause workout' : 'Play workout'}
          >
            {isPlaying ? (
              <Pause className="w-8 h-8 fill-current" />
            ) : (
              <Play className="w-8 h-8 fill-current ml-1" />
            )}
          </button>

          {/* Video Control Bar */}
          <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/85 via-black/50 to-transparent flex flex-col gap-2 z-20">
            {/* Progress bar */}
            <div
              className="w-full h-1.5 bg-white/30 rounded-full overflow-hidden cursor-pointer"
              onClick={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                const clickX = e.clientX - rect.left;
                const ratio = clickX / rect.width;
                setProgressSec(Math.floor(ratio * totalSec));
              }}
            >
              <div
                className="h-full bg-[#52B788] transition-all duration-300"
                style={{ width: `${percent}%` }}
              />
            </div>

            <div className="flex items-center justify-between text-white text-xs font-medium pt-1">
              <div className="flex items-center space-x-3">
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="hover:text-[#52B788] transition-colors"
                >
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                </button>
                <button
                  onClick={() => setProgressSec(0)}
                  title="Restart session"
                  className="hover:text-[#52B788] transition-colors"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setIsMuted(!isMuted)}
                  className="hover:text-[#52B788] transition-colors"
                >
                  {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
                <span className="font-mono text-[11px] opacity-90">
                  {formatTime(progressSec)} / {formatTime(totalSec)}
                </span>
              </div>

              <div className="flex items-center space-x-2">
                <span className="bg-[#285A48] px-2 py-0.5 rounded text-[10px] uppercase font-bold tracking-wider">
                  {tutorial.level}
                </span>
                <span className="text-[11px] opacity-80">{tutorial.views}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Information & Practice Details */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-black/10 dark:border-white/10 pb-4">
            <div>
              <div className="flex items-center space-x-2 mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-[#C27858]">
                  {tutorial.category}
                </span>
                <span className="text-xs opacity-50">•</span>
                <span className="text-xs opacity-75">{tutorial.date}</span>
              </div>
              <h2 className="font-serif-heading text-2xl sm:text-3xl font-semibold text-[#1F2522] dark:text-[#F3F7F4]">
                {tutorial.title}
              </h2>
            </div>

            <div className="flex items-center space-x-2">
              <button
                id="bookmark-btn"
                onClick={() => setSaved(!saved)}
                className={`p-2 rounded-lg border transition-colors flex items-center space-x-1.5 text-xs font-semibold ${
                  saved
                    ? 'bg-[#285A48] text-white border-[#285A48]'
                    : 'border-black/10 dark:border-white/10 hover:bg-black/5 dark:hover:bg-white/5'
                }`}
              >
                <Bookmark className={`w-4 h-4 ${saved ? 'fill-current' : ''}`} />
                <span>{saved ? 'Saved' : 'Save Asana'}</span>
              </button>

              <button
                id="share-btn"
                onClick={() => {
                  navigator.clipboard?.writeText(window.location.href);
                  alert('Class link copied to clipboard!');
                }}
                className="p-2 rounded-lg border border-black/10 dark:border-white/10 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
                title="Share class"
              >
                <Share2 className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Instructor & Metadata Overview */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-black/[0.03] dark:bg-white/[0.03] p-4 rounded-xl border border-black/5 dark:border-white/5 text-xs">
            <div className="flex items-center space-x-2">
              <User className="w-4 h-4 text-[#285A48] dark:text-[#52B788]" />
              <div>
                <p className="opacity-60 text-[10px] uppercase">Instructor</p>
                <p className="font-semibold">{tutorial.instructor}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4 text-[#285A48] dark:text-[#52B788]" />
              <div>
                <p className="opacity-60 text-[10px] uppercase">Duration</p>
                <p className="font-semibold">{tutorial.duration}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Award className="w-4 h-4 text-[#285A48] dark:text-[#52B788]" />
              <div>
                <p className="opacity-60 text-[10px] uppercase">Difficulty</p>
                <p className="font-semibold">{tutorial.level}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-[#285A48] dark:text-[#52B788]" />
              <div>
                <p className="opacity-60 text-[10px] uppercase">Equipment</p>
                <p className="font-semibold">Yoga Mat & Bolster</p>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="space-y-3">
            <h4 className="text-xs uppercase tracking-widest font-bold text-[#64726A] dark:text-[#9FB0A6]">
              Session Overview
            </h4>
            <p className="text-sm leading-relaxed text-[#45504A] dark:text-[#CBD8D0]">
              {tutorial.description}
            </p>
          </div>

          {/* Key Alignment Checkpoints */}
          {tutorial.keyPoints && (
            <div className="space-y-3">
              <h4 className="text-xs uppercase tracking-widest font-bold text-[#64726A] dark:text-[#9FB0A6]">
                Key Alignment & Mindful Cues
              </h4>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {tutorial.keyPoints.map((point, i) => (
                  <li
                    key={i}
                    className="flex items-start space-x-2 text-xs text-[#3E4943] dark:text-[#BCCEC3]"
                  >
                    <CheckCircle2 className="w-4 h-4 text-[#285A48] dark:text-[#52B788] shrink-0 mt-0.5" />
                    <span>{point}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
