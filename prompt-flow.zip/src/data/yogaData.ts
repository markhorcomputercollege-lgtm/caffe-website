import { YogaTutorial, Testimonial } from '../types';

export const HERO_STATS = [
  { label: 'Lessons', count: '130+' },
  { label: 'Courses', count: '30+' },
  { label: 'Tutors', count: '15+' },
];

export const FEATURED_VIDEOS: YogaTutorial[] = [
  {
    id: 'feat-1',
    title: 'Easiest Yoga Asanas For Every Working Women',
    category: 'Health',
    date: 'OCTOBER 13, 2023',
    image: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=800&q=80',
    duration: '18 min',
    instructor: 'Aria Vance',
    level: 'Beginner',
    type: 'video',
    views: '14.2k views',
    description: 'A gentle desk-worker recovery sequence designed to release neck stiffness, lower back tension, and restore energy during busy working days.',
    keyPoints: [
      'Gentle Cat-Cow for spine mobility',
      'Supported Pigeon Pose for tight hip flexors',
      'Chest-opening cactus arms & wrist decompression',
      'Mindful 3-minute diaphragmatic breathing'
    ],
    videoId: 'v1'
  },
  {
    id: 'feat-2',
    title: 'Craft Your Perfect Home Yoga Oasis',
    category: 'Tutorial',
    date: 'OCTOBER 13, 2023',
    image: 'https://images.unsplash.com/photo-1575052814086-f385e2e2ad1b?auto=format&fit=crop&w=800&q=80',
    duration: '12 min read',
    instructor: 'Elena Rostova',
    level: 'All Levels',
    type: 'article',
    views: '8.9k views',
    description: 'Transform any quiet corner into a dedicated sacred space with natural light, grounding floor textures, calming indoor botanicals, and organized props.',
    keyPoints: [
      'Choosing proper natural light orientation without glare',
      'Curating sustainable non-slip cork and natural rubber mats',
      'Aromatherapy pairing: Frankincense, Bergamot, and Sandalwood',
      'Storing bolsters, blocks, and straps discreetly'
    ]
  },
  {
    id: 'feat-3',
    title: '7 Great Books You Must Read Before Doing Yoga',
    category: 'Meditation',
    date: 'OCTOBER 13, 2023',
    image: 'https://images.unsplash.com/photo-1599447421416-3414500d18a5?auto=format&fit=crop&w=800&q=80',
    duration: '15 min read',
    instructor: 'David K. Thorne',
    level: 'All Levels',
    type: 'article',
    views: '21.5k views',
    description: 'Timeless spiritual literature and anatomical masterworks that deepen your connection to breath, philosophy, and mindful presence.',
    keyPoints: [
      'The Yoga Sutras of Patanjali (Translation & Commentary)',
      'Light on Yoga by B.K.S. Iyengar',
      'The Heart of Yoga by T.K.V. Desikachar',
      'Living Gita: The Complete Bhagavad Gita by Swami Satchidananda'
    ]
  },
  {
    id: 'feat-4',
    title: 'Vinyasa Flow for Morning Energy & Metabolism',
    category: 'Health',
    date: 'OCTOBER 15, 2023',
    image: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&w=800&q=80',
    duration: '25 min',
    instructor: 'Sienna Miller',
    level: 'Intermediate',
    type: 'video',
    views: '19.4k views',
    description: 'Awaken core vitality with dynamic sun salutations, warrior sequences, and balancing postures to energize body and clarity of mind.',
    keyPoints: [
      'Surya Namaskar A & B warm-up',
      'Warrior II and Reverse Warrior progression',
      'Half Moon (Ardha Chandrasana) balancing',
      'Cool-down seated twists and Savasana'
    ],
    videoId: 'v2'
  }
];

export const LATEST_TUTORIALS: YogaTutorial[] = [
  {
    id: 'lat-1',
    title: 'Create You Own Beautiful Yoga Studio At Home',
    category: 'Health',
    date: 'OCTOBER 13, 2023',
    image: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?auto=format&fit=crop&w=800&q=80',
    duration: '22 min',
    instructor: 'Chloe Bennett',
    level: 'All Levels',
    type: 'video',
    views: '11.8k views',
    description: 'Step-by-step guidance on setting up an inviting workout sanctuary with mirrors, plants, and organic acoustic warmth.',
    keyPoints: [
      'Optimal mat dimensions and wall clearance',
      'Sound resonance and bluetooth acoustic setup',
      'Incorporating living air-purifying foliage'
    ],
    videoId: 'v3'
  },
  {
    id: 'lat-2',
    title: '10 Things What You Should Not Do Before Yoga',
    category: 'Lifestyle',
    date: 'OCTOBER 13, 2023',
    image: 'https://images.unsplash.com/photo-1588286840104-8957b019727f?auto=format&fit=crop&w=800&q=80',
    duration: '8 min read',
    instructor: 'Maya Lin',
    level: 'Beginner',
    type: 'gallery',
    views: '34.1k views',
    description: 'Common pre-session pitfalls from heavy eating to dehydration that can hinder flexibility, calm breathing, and core engagement.',
    keyPoints: [
      'Avoid heavy solid meals within 2 hours of practice',
      'Skip caffeine spikes immediately before deep breathwork',
      'Warm up joints dynamically rather than going cold into deep stretches'
    ]
  },
  {
    id: 'lat-3',
    title: 'Doing Yoga In Nature Give Us Freshness',
    category: 'Pain Relief',
    date: 'OCTOBER 13, 2023',
    image: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&w=800&q=80',
    duration: '30 min',
    instructor: 'Tara & Michael',
    level: 'Intermediate',
    type: 'video',
    views: '16.7k views',
    description: 'Experience outdoor grounding on rocky shorelines and open meadows to reconnect with natural circadian rhythms and release joint stiffness.',
    keyPoints: [
      'Earthing and barefoot balance mechanics',
      'Pranayama with crisp seaside or forest negative ions',
      'Gentle shoulder and spine de-stressing'
    ],
    videoId: 'v4'
  },
  {
    id: 'lat-4',
    title: 'Advanced Yoga Sessions With Yoga Gurus',
    category: 'Lifestyle',
    date: 'OCTOBER 13, 2023',
    image: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=800&q=80',
    duration: '45 min',
    instructor: 'Master Arjun',
    level: 'Advanced',
    type: 'video',
    views: '27.4k views',
    description: 'Dive deep into aerial silks, inversion stability, Bandha activation, and extended pranayama with world-renowned yoga masters.',
    keyPoints: [
      'Mula and Uddiyana Bandha integration',
      'Suspension alignment for spinal decompression',
      'Advanced Sirsasana variations'
    ],
    videoId: 'v5'
  },
  {
    id: 'lat-5',
    title: 'How To Motivate Yourself For Daily Workout',
    category: 'Meditation',
    date: 'OCTOBER 13, 2023',
    image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=800&q=80',
    duration: '10 min read',
    instructor: 'Clara Oswald',
    level: 'All Levels',
    type: 'gallery',
    views: '18.2k views',
    description: 'Practical psychological triggers and habit loops to step onto the mat every sunrise with eagerness and self-compassion.',
    keyPoints: [
      'The 5-minute rule for overcoming initial resistance',
      'Preparing mat and hydration the night before',
      'Tracking small wins without perfectionism'
    ]
  },
  {
    id: 'lat-6',
    title: 'Why You Need A Good Yoga Instructor',
    category: 'Lifestyle',
    date: 'OCTOBER 13, 2023',
    image: 'https://images.unsplash.com/photo-1593811167562-9cef47bfc4d7?auto=format&fit=crop&w=800&q=80',
    duration: '35 min',
    instructor: 'Jessica & Sophia',
    level: 'Intermediate',
    type: 'video',
    views: '22.0k views',
    description: 'How individualized anatomical hands-on adjustments safeguard your joints, optimize alignment, and unlock deeper mobility.',
    keyPoints: [
      'Detecting subtle hip tilts and shoulder impingements',
      'Building injury-free long term practice',
      'Personalized breath pacing'
    ],
    videoId: 'v6'
  }
];

export const TESTIMONIAL_DATA: Testimonial = {
  quote: "“I’m overjoyed to learn about your remarkable journey. Seeing you radiate happiness. With love”",
  author: "OLIVIA BROWN",
  location: "MIAMI",
  image: "https://images.unsplash.com/photo-1552196563-552368177579?auto=format&fit=crop&w=800&q=80"
};
