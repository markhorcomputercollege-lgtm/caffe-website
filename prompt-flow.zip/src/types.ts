export type YogaCategory = 'Health' | 'Tutorial' | 'Meditation' | 'Lifestyle' | 'Pain Relief';

export interface YogaTutorial {
  id: string;
  title: string;
  category: YogaCategory;
  date: string;
  image: string;
  duration?: string;
  instructor: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced' | 'All Levels';
  type: 'video' | 'gallery' | 'article';
  views: string;
  description: string;
  keyPoints?: string[];
  videoId?: string;
}

export interface Testimonial {
  quote: string;
  author: string;
  location: string;
  image: string;
}
